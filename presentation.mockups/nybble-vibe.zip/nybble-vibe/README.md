# 🎮 Nybble Vibe - Chrome Extension

> Gamified meeting engagement & feedback platform for Nybble Group

## 🚀 Quick Start

### Installation (Development Mode)

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right)
3. Click **Load unpacked**
4. Select the `nybble-vibe` folder
5. The extension icon should appear in your toolbar!

### Testing

1. Go to [Google Meet](https://meet.google.com)
2. Join or create a meeting
3. The Nybble Vibe sidebar should appear automatically!
4. If not, click the extension icon and select "Open Sidebar"

## 📁 Project Structure

```
nybble-vibe/
├── manifest.json          # Extension configuration
├── content/
│   ├── inject.js          # Injects sidebar into Google Meet
│   └── inject.css         # All styles for the sidebar
├── sidebar/
│   └── app.js             # Main application logic
├── data/
│   └── mockData.js        # Mock data for events, polls, etc.
├── popup/
│   ├── popup.html         # Extension popup UI
│   └── popup.js           # Popup logic
├── assets/
│   └── icons/             # Extension icons
└── README.md
```

## ✨ Features

### Pre-Meeting
- 📋 View agenda
- 🎯 Set personal goals
- ❓ Prepare questions
- 👥 See attendees

### During Meeting
- ✅ Automatic attendance tracking
- 📊 Live polls
- ⚡ Quick emoji reactions
- 💬 Anonymous Q&A

### Post-Meeting
- ⭐ Rate the meeting
- 🤖 AI-powered Q&A on transcript
- 🏆 View final score & rank
- 🎖️ Earn badges

## 🎮 Gamification

### Points
| Action | Points |
|--------|--------|
| Set goals | +20 |
| Prepare question | +15 |
| Attendance | +50 |
| Poll vote | +15 |
| Reaction | +5 |
| Ask question | +25 |
| Rate meeting | +10 |
| AI question | +10 |

### Badges
- 🎯 **Full Journey** - Complete PRE + LIVE + POST
- 📊 **Poll Master** - Vote in all polls
- 💬 **Curious Mind** - Ask 3+ questions
- 🔥 **On Fire** - 5 event streak
- ⏰ **Early Bird** - Join 5 min early
- 👑 **Champion** - Finish #1

## 🛠️ Development

### Modifying the Extension

1. Edit files in the `nybble-vibe` folder
2. Go to `chrome://extensions/`
3. Click the refresh icon (🔄) on the Nybble Vibe extension
4. Reload Google Meet to see changes

### Key Files to Edit

- **`data/mockData.js`** - Change events, polls, participants
- **`sidebar/app.js`** - Main app logic and UI rendering
- **`content/inject.css`** - All styling

### Changing the Phase

In `mockData.js`, change the event phase:
```javascript
phase: 'pre',   // Pre-meeting
phase: 'live',  // During meeting
phase: 'post',  // After meeting
```

Or use the tabs in the sidebar to switch phases.

## 🎨 Customization

### Colors (in inject.css)
```css
--accent-primary: #6366F1;    /* Indigo */
--accent-secondary: #22D3EE;  /* Cyan */
--success: #10B981;           /* Green */
```

### Adding New Reactions
In `app.js`, find the reactions array:
```javascript
['🔥', '👏', '💡', '🤔', '❤️', '🚀', '😂', '🎯']
```

### Adding New Polls
In `mockData.js`, add to the `MOCK_POLLS` array:
```javascript
{
  id: 'poll-3',
  question: 'Your question here?',
  options: [
    { id: 'a', text: 'Option A', votes: 0 },
    { id: 'b', text: 'Option B', votes: 0 },
  ],
  status: 'active', // or 'draft'
  totalVotes: 0,
}
```

## 🔮 Future Enhancements

- [ ] Real backend API
- [ ] Database persistence
- [ ] Real-time sync
- [ ] Admin dashboard
- [ ] Real AI integration (OpenAI)
- [ ] Slack integration
- [ ] Calendar sync

## 📝 Notes

- This is an MVP with mock data
- All data is stored locally in the browser
- No real API calls are made
- The "AI" responses are pre-defined in mockData.js

## 🤝 Contributing

1. Create a feature branch
2. Make your changes
3. Test in Chrome
4. Submit a pull request

## 📄 License

MIT License - Nybble Group

---

Made with 💜 by Nybble Labs

