// ============================================
// NYBBLE VIBE - Mock Database
// Simulates the backend API/Database
// ============================================

window.NYBBLE_DB = {
  
  // ============================================
  // EVENTS TABLE
  // Each event has a meeting URL to match
  // ============================================
  events: [
    {
      id: 'evt-010',
      title: '¡Tech Night: 2da edición!',
      description: 'Monthly tech talk about AI trends and implementations',
      meetingUrl: 'https://meet.google.com/rqz-tgsc-ofw',
      meetingUrlPattern: 'rqz-tgsc-ofw', // Pattern for matching
      scheduledStart: '2024-12-03T15:00:00',
      scheduledEnd: '2024-12-03T16:00:00',
      phase: 'live', // 'pre' | 'live' | 'post' - comes from backend
      status: 'active', // 'draft' | 'active' | 'completed' | 'cancelled'
      host: {
        id: 'user-001',
        name: 'Carlos Martinez',
        avatar: '👨‍💻'
      },
      agenda: [
        { id: 'ag-1', time: '15:00', duration: 10, title: 'Welcome & Intro', presenter: 'Carlos' },
        { id: 'ag-2', time: '15:10', duration: 20, title: 'AI Trends Overview', presenter: 'Maria' },
        { id: 'ag-3', time: '15:30', duration: 15, title: 'Live Demo', presenter: 'Juan' },
        { id: 'ag-4', time: '15:45', duration: 15, title: 'Q&A', presenter: 'All' }
      ],
      settings: {
        allowAnonymousQuestions: true,
        showLeaderboard: true,
        enableReactions: true,
        maxReactionsPerUser: 10
      },
      createdAt: '2024-12-01T10:00:00',
      updatedAt: '2024-12-03T14:30:00'
    },
    {
      id: 'evt-003',
      title: 'Cruising Power Stand Up',
      description: 'Daily stand up meeting',
      meetingUrl: 'https://meet.google.com/ebm-sqko-bxf',
      meetingUrlPattern: 'ebm-sqko-bxf',
      scheduledStart: '2025-12-04T09:00:00',
      scheduledEnd: '2025-12-04T09:30:00',
      phase: 'live',
      status: 'active',
      host: {
        id: 'user-003',
        name: 'Team Lead',
        avatar: '🚢'
      },
      agenda: [
        { id: 'ag-1', time: '09:00', duration: 5, title: 'Yesterday Updates', presenter: 'All' },
        { id: 'ag-2', time: '09:05', duration: 10, title: 'Today Plans', presenter: 'All' },
        { id: 'ag-3', time: '09:15', duration: 10, title: 'Blockers', presenter: 'All' },
        { id: 'ag-4', time: '09:25', duration: 5, title: 'Wrap Up', presenter: 'Lead' }
      ],
      settings: {
        allowAnonymousQuestions: true,
        showLeaderboard: true,
        enableReactions: true,
        maxReactionsPerUser: 10
      },
      createdAt: '2025-12-01T10:00:00',
      updatedAt: '2025-12-04T08:30:00'
    },
    {
      id: 'evt-002',
      title: '¡Tech Night: 3da edición!',
      description: 'End of sprint review and retrospective',
      meetingUrl: 'https://meet.google.com/dbd-ochb-qiq',
      meetingUrlPattern: 'dbd-ochb-qiq', // Pattern for matching
      scheduledStart: '2024-12-05T10:00:00',
      scheduledEnd: '2024-12-05T11:00:00',
      phase: 'pre',
      status: 'active',
      host: {
        id: 'user-002',
        name: 'Ana Garcia',
        avatar: '👩‍💼'
      },
      agenda: [
        { id: 'ag-1', time: '10:00', duration: 15, title: 'Sprint Summary', presenter: 'Ana' },
        { id: 'ag-2', time: '10:15', duration: 30, title: 'Demo Features', presenter: 'Team' },
        { id: 'ag-3', time: '10:45', duration: 15, title: 'Retro & Next Steps', presenter: 'All' }
      ],
      settings: {
        allowAnonymousQuestions: true,
        showLeaderboard: true,
        enableReactions: true,
        maxReactionsPerUser: 10
      },
      createdAt: '2024-12-01T10:00:00',
      updatedAt: '2024-12-03T14:30:00'
    }
  ],
  
  // ============================================
  // POLLS TABLE
  // Linked to events
  // ============================================
  polls: [
    {
      id: 'poll-003',
      eventId: 'evt-003',
      question: '¿Cómo va tu día hoy?',
      type: 'single',
      options: [
        { id: 'opt-1', text: '🚀 Productivo', votes: 5 },
        { id: 'opt-2', text: '😊 Normal', votes: 3 },
        { id: 'opt-3', text: '😓 Complicado', votes: 1 },
        { id: 'opt-4', text: '☕ Necesito café', votes: 4 }
      ],
      status: 'active',
      showResults: true,
      points: 15,
      createdAt: '2025-12-04T09:05:00'
    },
    {
      id: 'poll-001',
      eventId: 'evt-010',
      question: '¿Qué área de AI te interesa más?',
      type: 'single', // 'single' | 'multiple' | 'rating'
      options: [
        { id: 'opt-1', text: 'Machine Learning', votes: 12 },
        { id: 'opt-2', text: 'Computer Vision', votes: 8 },
        { id: 'opt-3', text: 'NLP / LLMs', votes: 15 },
        { id: 'opt-4', text: 'Robotics', votes: 5 }
      ],
      status: 'active', // 'draft' | 'active' | 'closed'
      showResults: true,
      points: 15,
      createdAt: '2024-12-03T15:15:00'
    },
    {
      id: 'poll-002',
      eventId: 'evt-001',
      question: '¿Implementarías AI en tu proyecto actual?',
      type: 'single',
      options: [
        { id: 'opt-1', text: 'Sí, definitivamente', votes: 20 },
        { id: 'opt-2', text: 'Tal vez, necesito investigar', votes: 10 },
        { id: 'opt-3', text: 'No, no aplica', votes: 3 }
      ],
      status: 'closed',
      showResults: true,
      points: 15,
      createdAt: '2024-12-03T15:30:00'
    }
  ],
  
  // ============================================
  // ATTENDANCE TABLE
  // Records who attended which event
  // ============================================
  attendance: [
    { id: 'att-001', eventId: 'evt-001', odUserId: 'user-003', odJoinedAt: '2024-12-03T14:58:00', points: 50 },
    { id: 'att-002', eventId: 'evt-001', odUserId: 'user-004', joinedAt: '2024-12-03T15:02:00', points: 50 },
    { id: 'att-003', eventId: 'evt-001', userId: 'user-005', joinedAt: '2024-12-03T15:05:00', points: 50 },
  ],
  
  // ============================================
  // POLL VOTES TABLE
  // Records who voted on what
  // ============================================
  pollVotes: [
    { id: 'vote-001', pollId: 'poll-001', odUserId: 'user-003', optionId: 'opt-3', votedAt: '2024-12-03T15:16:00' },
    { id: 'vote-002', pollId: 'poll-001', userId: 'user-004', optionId: 'opt-1', votedAt: '2024-12-03T15:17:00' },
  ],
  
  // ============================================
  // REACTIONS TABLE
  // ============================================
  reactions: [
    { id: 'react-001', eventId: 'evt-001', userId: 'user-003', emoji: '🔥', timestamp: '2024-12-03T15:20:00' },
    { id: 'react-002', eventId: 'evt-001', userId: 'user-003', emoji: '👏', timestamp: '2024-12-03T15:21:00' },
  ],
  
  // ============================================
  // QUESTIONS TABLE (Q&A)
  // ============================================
  questions: [
    { 
      id: 'q-001', 
      eventId: 'evt-001', 
      userId: 'user-003', 
      text: '¿Cuál es el costo promedio de implementar un LLM?',
      anonymous: false,
      status: 'answered', // 'pending' | 'answered' | 'dismissed'
      upvotes: 5,
      createdAt: '2024-12-03T15:25:00'
    }
  ],
  
  // ============================================
  // LEADERBOARD (computed from attendance + votes + reactions)
  // In real app, this would be computed server-side
  // ============================================
  getLeaderboard: function(eventId) {
    // Mock leaderboard data
    return [
      { odUserId: 'user-003', name: 'María López', avatar: '👩‍💻', points: 285 },
      { odUserId: 'user-004', name: 'Juan Pérez', avatar: '👨‍🎨', points: 240 },
      { userId: 'user-005', name: 'Ana Torres', avatar: '👩‍🔬', points: 195 },
      { userId: 'user-006', name: 'Carlos Ruiz', avatar: '🧑‍💻', points: 150 },
      { userId: 'user-007', name: 'Laura Kim', avatar: '👩‍🚀', points: 120 },
    ];
  },
  
  // ============================================
  // AI RESPONSES (for post-meeting Q&A)
  // In real app, this would be generated from transcription
  // ============================================
  aiResponses: {
    'action': 'Based on the meeting:\n\n1. ✅ Juan will prepare the AI demo for next week\n2. ✅ Maria will share the cost analysis document\n3. ✅ Team will evaluate LLM options by Friday',
    'cost': 'The team discussed that implementing a basic LLM solution costs between $500-2000/month depending on usage. Fine-tuning adds $5k-20k upfront.',
    'next': 'Next steps mentioned:\n• Research OpenAI vs Anthropic pricing\n• POC for customer support chatbot\n• Review security requirements',
    'default': 'I can answer questions about action items, costs, next steps, or specific topics discussed in the meeting.'
  },
  
  // ============================================
  // BADGES DEFINITIONS
  // ============================================
  badges: {
    'early-bird': { id: 'early-bird', name: 'Early Bird', icon: '🐦', description: 'Joined 5 min before start' },
    'poll-master': { id: 'poll-master', name: 'Poll Master', icon: '📊', description: 'Voted in all polls' },
    'engaged': { id: 'engaged', name: 'Super Engaged', icon: '🔥', description: '10+ reactions' },
    'curious': { id: 'curious', name: 'Curious Mind', icon: '❓', description: 'Asked 3+ questions' },
    'full-journey': { id: 'full-journey', name: 'Full Journey', icon: '🎯', description: 'Completed PRE/LIVE/POST' },
    'streak-3': { id: 'streak-3', name: '3-Day Streak', icon: '🔥', description: '3 events in a row' }
  },
  
  // ============================================
  // CURRENT USER (simulates logged-in user)
  // In real app, comes from auth
  // ============================================
  currentUser: {
    id: 'user-current',
    name: 'You',
    email: 'you@nybble.io',
    avatar: '🦊'
  }
};

// ============================================
// API MOCK FUNCTIONS
// Simulates API calls to backend
// ============================================

window.NYBBLE_API = {
  
  // Find event by meeting URL
  findEventByUrl: async function(url) {
    // Simulate API delay
    await new Promise(r => setTimeout(r, 300));
    
    const event = window.NYBBLE_DB.events.find(e => 
      url.includes(e.meetingUrlPattern) && e.status === 'active'
    );
    
    return event || null;
  },
  
  // Mark attendance
  markAttendance: async function(eventId, odUserId) {
    await new Promise(r => setTimeout(r, 200));
    
    const existing = window.NYBBLE_DB.attendance.find(
      a => a.eventId === eventId && a.odUserId === odUserId
    );
    
    if (!existing) {
      const newAtt = {
        id: 'att-' + Date.now(),
        eventId,
        odUserId,
        joinedAt: new Date().toISOString(),
        points: 50
      };
      window.NYBBLE_DB.attendance.push(newAtt);
      return { success: true, points: 50, isNew: true };
    }
    
    return { success: true, points: 0, isNew: false };
  },
  
  // Get polls for event
  getPolls: async function(eventId) {
    await new Promise(r => setTimeout(r, 200));
    return window.NYBBLE_DB.polls.filter(p => p.eventId === eventId);
  },
  
  // Submit vote
  submitVote: async function(pollId, odUserId, optionId) {
    await new Promise(r => setTimeout(r, 200));
    
    const poll = window.NYBBLE_DB.polls.find(p => p.id === pollId);
    if (!poll) return { success: false, error: 'Poll not found' };
    
    const option = poll.options.find(o => o.id === optionId);
    if (option) option.votes++;
    
    window.NYBBLE_DB.pollVotes.push({
      id: 'vote-' + Date.now(),
      pollId,
      odUserId,
      optionId,
      votedAt: new Date().toISOString()
    });
    
    return { success: true, points: poll.points };
  },
  
  // Submit reaction
  submitReaction: async function(eventId, odUserId, emoji) {
    await new Promise(r => setTimeout(r, 100));
    
    window.NYBBLE_DB.reactions.push({
      id: 'react-' + Date.now(),
      eventId,
      odUserId,
      emoji,
      timestamp: new Date().toISOString()
    });
    
    return { success: true, points: 5 };
  },
  
  // Submit question
  submitQuestion: async function(eventId, odUserId, text, anonymous = false) {
    await new Promise(r => setTimeout(r, 200));
    
    window.NYBBLE_DB.questions.push({
      id: 'q-' + Date.now(),
      eventId,
      odUserId,
      text,
      anonymous,
      status: 'pending',
      upvotes: 0,
      createdAt: new Date().toISOString()
    });
    
    return { success: true, points: 25 };
  },
  
  // Get leaderboard
  getLeaderboard: async function(eventId) {
    await new Promise(r => setTimeout(r, 200));
    return window.NYBBLE_DB.getLeaderboard(eventId);
  },
  
  // Ask AI about meeting
  askAI: async function(eventId, question) {
    await new Promise(r => setTimeout(r, 500));
    
    const q = question.toLowerCase();
    const responses = window.NYBBLE_DB.aiResponses;
    
    for (const [key, value] of Object.entries(responses)) {
      if (q.includes(key)) return { success: true, response: value };
    }
    
    return { success: true, response: responses.default };
  },
  
  // Submit rating
  submitRating: async function(eventId, odUserId, rating) {
    await new Promise(r => setTimeout(r, 200));
    return { success: true, points: 10 };
  }
};

console.log('🎮 Nybble Vibe: Mock Database loaded');
