// ============================================
// NYBBLE VIBE - Content Script (Sidebar Injection)
// ============================================

(function() {
  'use strict';
  
  console.log('🎮 Nybble Vibe: Script loaded on', window.location.href);
  
  // Listen for messages from popup
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    try {
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.log('🎮 Nybble Vibe: Received message:', request);
        
        if (request.action === 'toggleSidebar') {
          const sidebar = document.getElementById('nybble-vibe-sidebar');
          const minimizedBtn = document.getElementById('nybble-vibe-minimized');
          
          if (sidebar) {
            sidebar.classList.toggle('minimized');
            if (minimizedBtn) minimizedBtn.classList.toggle('hidden');
          }
          
          sendResponse({ success: true });
        }
        
        return true; // Keep message channel open
      });
    } catch (e) {
      console.log('🎮 Nybble Vibe: Could not set up message listener:', e);
    }
  }
  
  // Prevent multiple injections
  if (document.getElementById('nybble-vibe-sidebar')) {
    console.log('🎮 Nybble Vibe: Already loaded');
    return;
  }
  
  console.log('🎮 Nybble Vibe: Initializing...');
  
  // Function to check if body is ready
  function waitForBody(callback, maxAttempts = 50) {
    let attempts = 0;
    
    function check() {
      attempts++;
      if (document.body) {
        console.log('🎮 Nybble Vibe: Body ready after', attempts, 'attempts');
        callback();
      } else if (attempts < maxAttempts) {
        setTimeout(check, 100);
      } else {
        console.error('🎮 Nybble Vibe: Body not found after', maxAttempts, 'attempts');
      }
    }
    
    check();
  }
  
  // Wait for page to be ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => waitForBody(initSidebar));
  } else if (document.body) {
    // Small delay to let Meet's JS initialize
    setTimeout(initSidebar, 500);
  } else {
    waitForBody(initSidebar);
  }
  
  function initSidebar() {
    // Create sidebar container
    const sidebar = document.createElement('div');
    sidebar.id = 'nybble-vibe-sidebar';
    sidebar.innerHTML = `
      <div class="nv-sidebar-container">
        <div class="nv-sidebar-header">
          <div class="nv-logo">
            <span class="nv-logo-icon">🎮</span>
            <span class="nv-logo-text">NYBBLE VIBE</span>
          </div>
          <div class="nv-header-actions">
            <button class="nv-btn-icon" id="nv-minimize" title="Minimize">─</button>
          </div>
        </div>
        <div class="nv-sidebar-content" id="nv-content">
          <div class="nv-loading">
            <div class="nv-spinner"></div>
            <p>Loading experience...</p>
          </div>
        </div>
      </div>
    `;
    
    // Create minimized button
    const minimizedBtn = document.createElement('div');
    minimizedBtn.id = 'nybble-vibe-minimized';
    minimizedBtn.className = 'nv-minimized-btn hidden';
    minimizedBtn.innerHTML = '🎮';
    minimizedBtn.title = 'Open Nybble Vibe';
    
    // Add to page
    document.body.appendChild(sidebar);
    document.body.appendChild(minimizedBtn);
    
    // Event listeners
    document.getElementById('nv-minimize').addEventListener('click', toggleMinimize);
    minimizedBtn.addEventListener('click', toggleMinimize);
    
    function toggleMinimize() {
      sidebar.classList.toggle('minimized');
      minimizedBtn.classList.toggle('hidden');
    }
    
    // Initialize app after short delay
    setTimeout(initApp, 500);
    
    console.log('🎮 Nybble Vibe: Sidebar injected!');
  }
  
  // ============================================
  // MAIN APPLICATION
  // ============================================
  
  function initApp() {
    // Use the global NYBBLE_MOCK from mockData.js
    const MOCK = window.NYBBLE_MOCK;
    
    if (!MOCK) {
      console.error('🎮 Nybble Vibe: Mock data not loaded!');
      return;
    }
    
    // App State
    const state = {
      phase: 'pre',
      event: { ...MOCK.event },
      currentUser: { ...MOCK.currentUser },
      polls: [...MOCK.polls],
      participants: [...MOCK.participants],
      votedPolls: [],
      aiMessages: [],
      preparedQuestions: [],
      goals: '',
    };
    
    // Make state globally accessible for debugging
    window.NYBBLE_STATE = state;
    
    // Initialize
    renderApp();
    
    // ============================================
    // RENDER FUNCTIONS
    // ============================================
    
    function renderApp() {
      const content = document.getElementById('nv-content');
      if (!content) return;
      
      content.innerHTML = `
        ${renderEventInfo()}
        ${renderStats()}
        ${renderTabs()}
        <div id="nv-tab-content">
          ${renderCurrentPhase()}
        </div>
      `;
      
      setupEventListeners();
    }
    
    function renderEventInfo() {
      const phaseLabels = {
        pre: '⏳ PRE-EVENT',
        live: '🔴 LIVE',
        post: '✅ COMPLETED'
      };
      
      return `
        <div class="nv-event-info">
          <span class="nv-phase-badge ${state.phase}">${phaseLabels[state.phase]}</span>
          <h2 class="nv-event-title">${state.event.title}</h2>
          <div class="nv-event-time">
            <span>📅</span>
            <span>${formatEventTime()}</span>
          </div>
        </div>
      `;
    }
    
    function renderStats() {
      return `
        <div class="nv-stats-card">
          <div class="nv-stat">
            <div class="nv-stat-value">⭐ ${state.currentUser.points}</div>
            <div class="nv-stat-label">Points</div>
          </div>
          <div class="nv-stat">
            <div class="nv-stat-value">#${state.currentUser.rank || '–'}</div>
            <div class="nv-stat-label">Rank</div>
          </div>
          <div class="nv-stat">
            <div class="nv-stat-value">🔥 ${state.currentUser.streak}</div>
            <div class="nv-stat-label">Streak</div>
          </div>
        </div>
      `;
    }
    
    function renderTabs() {
      return `
        <div class="nv-tabs">
          <button class="nv-tab ${state.phase === 'pre' ? 'active' : ''}" data-phase="pre">
            📋 Prepare
          </button>
          <button class="nv-tab ${state.phase === 'live' ? 'active' : ''}" data-phase="live">
            ⚡ Live
          </button>
          <button class="nv-tab ${state.phase === 'post' ? 'active' : ''}" data-phase="post">
            📊 Results
          </button>
        </div>
      `;
    }
    
    function renderCurrentPhase() {
      switch (state.phase) {
        case 'pre': return renderPrePhase();
        case 'live': return renderLivePhase();
        case 'post': return renderPostPhase();
        default: return '';
      }
    }
    
    // ============================================
    // PRE-MEETING PHASE
    // ============================================
    
    function renderPrePhase() {
      return `
        <div class="nv-section">
          <h3 class="nv-section-title">📋 Agenda</h3>
          <div class="nv-card">
            ${state.event.agenda.map(item => `
              <div class="nv-agenda-item">
                <span class="nv-agenda-time">${item.duration}m</span>
                <span class="nv-agenda-title">${item.title}</span>
                <span class="nv-agenda-presenter">${item.presenter}</span>
              </div>
            `).join('')}
          </div>
        </div>
        
        <div class="nv-section">
          <h3 class="nv-section-title">🎯 Set Your Goals</h3>
          <div class="nv-card">
            <p style="font-size: 13px; color: #A1A1AA; margin: 0 0 12px;">
              What do you want to get from this meeting?
            </p>
            <textarea class="nv-textarea" id="nv-goals-input" placeholder="E.g., Learn about AI integration...">${state.goals}</textarea>
            <button class="nv-btn nv-btn-primary" id="nv-save-goals" style="margin-top: 12px;">
              Save Goals (+20 pts)
            </button>
          </div>
        </div>
        
        <div class="nv-section">
          <h3 class="nv-section-title">❓ Prepare Questions</h3>
          <div class="nv-card">
            <div id="nv-prepared-questions">
              ${state.preparedQuestions.length === 0 ? `
                <p style="font-size: 13px; color: #71717A; margin: 0 0 12px;">
                  No questions yet. Add some!
                </p>
              ` : state.preparedQuestions.map((q, i) => `
                <div class="nv-question-item">
                  <div class="nv-question-checkbox ${q.asked ? 'checked' : ''}" data-index="${i}"></div>
                  <span class="nv-question-text">${q.text}</span>
                </div>
              `).join('')}
            </div>
            <div style="display: flex; gap: 8px; margin-top: 12px;">
              <input type="text" class="nv-input" id="nv-question-input" placeholder="Type a question..."/>
              <button class="nv-btn nv-btn-secondary" id="nv-add-question" style="width: auto; padding: 12px 16px;">+</button>
            </div>
          </div>
        </div>
        
        <div class="nv-section">
          <h3 class="nv-section-title">👥 Who's Joining (${state.participants.length})</h3>
          <div style="display: flex; flex-wrap: wrap; gap: 8px;">
            ${state.participants.slice(0, 8).map(p => `
              <div style="font-size: 28px;" title="${p.name}">${p.avatar}</div>
            `).join('')}
            ${state.participants.length > 8 ? `<span style="color: #71717A; display: flex; align-items: center;">+${state.participants.length - 8}</span>` : ''}
          </div>
        </div>
        
        <div class="nv-section">
          <button class="nv-btn nv-btn-primary" id="nv-go-live">🚀 Start Live Experience</button>
        </div>
      `;
    }
    
    // ============================================
    // LIVE PHASE
    // ============================================
    
    function renderLivePhase() {
      const activePoll = state.polls.find(p => p.status === 'active');
      
      return `
        <div class="nv-section">
          <div class="nv-card" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(16, 185, 129, 0.05)); border-color: rgba(16, 185, 129, 0.3);">
            <div style="display: flex; align-items: center; gap: 12px;">
              <span style="font-size: 32px;">✅</span>
              <div>
                <div style="font-size: 14px; font-weight: 600; color: #10B981;">Attendance Tracked!</div>
                <div style="font-size: 12px; color: #71717A;">You joined at ${new Date().toLocaleTimeString()}</div>
              </div>
            </div>
          </div>
        </div>
        
        ${activePoll ? `
          <div class="nv-section">
            <h3 class="nv-section-title">📊 Active Poll</h3>
            <div class="nv-poll">
              <div class="nv-poll-question">${activePoll.question}</div>
              <div id="nv-poll-options">
                ${activePoll.options.map(opt => {
                  const percentage = Math.round((opt.votes / activePoll.totalVotes) * 100) || 0;
                  const isVoted = state.votedPolls.includes(activePoll.id);
                  const isSelected = state.currentUser.selectedOption === opt.id;
                  return `
                    <div class="nv-poll-option ${isSelected ? 'selected' : ''}" 
                         data-poll-id="${activePoll.id}" 
                         data-option-id="${opt.id}"
                         style="position: relative; overflow: hidden; ${isVoted ? 'pointer-events: none;' : ''}">
                      ${isVoted ? `<div class="nv-poll-option-bar" style="width: ${percentage}%;"></div>` : ''}
                      <div class="nv-poll-option-radio"></div>
                      <span class="nv-poll-option-text">${opt.text}</span>
                      ${isVoted ? `<span style="color: #6366F1; font-weight: 600;">${percentage}%</span>` : ''}
                    </div>
                  `;
                }).join('')}
              </div>
              <div class="nv-poll-stats">
                <span>${activePoll.totalVotes} votes</span>
                <span>${state.votedPolls.includes(activePoll.id) ? '✅ You voted!' : 'Vote to earn +15 pts'}</span>
              </div>
            </div>
          </div>
        ` : ''}
        
        <div class="nv-section">
          <h3 class="nv-section-title">⚡ Quick Reactions</h3>
          <div class="nv-card">
            <p style="font-size: 12px; color: #71717A; margin: 0 0 12px; text-align: center;">
              Tap to react! (+5 pts each, max 10)
            </p>
            <div class="nv-reactions">
              ${['🔥', '👏', '💡', '🤔', '❤️', '🚀', '😂', '🎯'].map(emoji => `
                <button class="nv-reaction-btn" data-emoji="${emoji}">${emoji}</button>
              `).join('')}
            </div>
            <div style="text-align: center; margin-top: 12px; font-size: 12px; color: #71717A;">
              Reactions: ${state.currentUser.reactions.length}/10
            </div>
          </div>
        </div>
        
        <div class="nv-section">
          <h3 class="nv-section-title">🙋 Ask a Question</h3>
          <div class="nv-card">
            <div style="display: flex; gap: 8px;">
              <input type="text" class="nv-input" id="nv-live-question-input" placeholder="Ask anonymously..."/>
              <button class="nv-btn nv-btn-primary" id="nv-ask-live-question" style="width: auto; padding: 12px 16px;">Ask</button>
            </div>
          </div>
        </div>
        
        <div class="nv-section">
          <h3 class="nv-section-title">🏆 Leaderboard</h3>
          ${renderLeaderboard(5)}
        </div>
        
        <div class="nv-section">
          <button class="nv-btn nv-btn-secondary" id="nv-end-meeting">End Meeting → Results</button>
        </div>
      `;
    }
    
    // ============================================
    // POST PHASE
    // ============================================
    
    function renderPostPhase() {
      return `
        <div class="nv-section">
          <h3 class="nv-section-title">📊 Your Participation</h3>
          <div class="nv-card">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
              <div style="text-align: center; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px;">
                <div style="font-size: 24px;">⏱️</div>
                <div style="font-size: 18px; font-weight: 700; color: #F4F4F5;">45 min</div>
                <div style="font-size: 11px; color: #71717A;">Attended</div>
              </div>
              <div style="text-align: center; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px;">
                <div style="font-size: 24px;">⚡</div>
                <div style="font-size: 18px; font-weight: 700; color: #F4F4F5;">${state.currentUser.reactions.length}</div>
                <div style="font-size: 11px; color: #71717A;">Reactions</div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="nv-section">
          <h3 class="nv-section-title">⭐ Rate This Meeting</h3>
          <div class="nv-card">
            <div class="nv-rating">
              ${['😫', '😕', '😐', '🙂', '🤩'].map((emoji, i) => `
                <button class="nv-rating-btn ${state.currentUser.rating === i + 1 ? 'selected' : ''}" data-rating="${i + 1}">${emoji}</button>
              `).join('')}
            </div>
          </div>
        </div>
        
        <div class="nv-section">
          <h3 class="nv-section-title">🤖 Ask the Meeting</h3>
          <div class="nv-ai-chat">
            <div class="nv-ai-header">
              <span class="nv-ai-icon">🤖</span>
              <span class="nv-ai-title">AI Meeting Q&A</span>
            </div>
            <div class="nv-ai-messages" id="nv-ai-messages">
              ${state.aiMessages.length === 0 ? `
                <div class="nv-ai-message assistant">
                  Hi! Ask me anything about the meeting:<br><br>
                  • "What were the action items?"<br>
                  • "What was decided about costs?"<br>
                  • "Q1 plans?"
                </div>
              ` : state.aiMessages.map(msg => `
                <div class="nv-ai-message ${msg.role}">${msg.content}</div>
              `).join('')}
            </div>
            <div class="nv-ai-input-group">
              <input type="text" class="nv-input" id="nv-ai-input" placeholder="Ask about the meeting..."/>
              <button class="nv-btn nv-btn-primary" id="nv-ai-send">Ask</button>
            </div>
          </div>
        </div>
        
        <div class="nv-section">
          <h3 class="nv-section-title">🏆 Final Results</h3>
          <div class="nv-card" style="text-align: center; background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(34, 211, 238, 0.1));">
            <div style="font-size: 48px; margin-bottom: 8px;">${state.currentUser.avatar}</div>
            <div style="font-size: 32px; font-weight: 700; color: #F4F4F5;">⭐ ${state.currentUser.points} pts</div>
            <div style="font-size: 18px; color: #6366F1; margin-top: 4px;">Rank #${state.currentUser.rank}</div>
          </div>
        </div>
        
        <div class="nv-section">
          <h3 class="nv-section-title">📊 Leaderboard</h3>
          ${renderLeaderboard(8)}
        </div>
        
        <div class="nv-section">
          <button class="nv-btn nv-btn-secondary" id="nv-share-slack">💬 Share on Slack</button>
        </div>
      `;
    }
    
    // ============================================
    // HELPERS
    // ============================================
    
    function renderLeaderboard(limit) {
      const all = [...state.participants, { ...state.currentUser, name: 'You', isCurrentUser: true }]
        .sort((a, b) => b.points - a.points)
        .slice(0, limit);
      
      return `
        <div class="nv-card" style="padding: 12px;">
          ${all.map((p, i) => {
            const rank = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;
            return `
              <div class="nv-leaderboard-item ${p.isCurrentUser ? 'current-user' : ''}">
                <span class="nv-leaderboard-rank ${i < 3 ? 'top-3' : ''}">${rank}</span>
                <span class="nv-leaderboard-avatar">${p.avatar}</span>
                <span class="nv-leaderboard-name">${p.name}</span>
                <span class="nv-leaderboard-points">${p.points} pts</span>
              </div>
            `;
          }).join('')}
        </div>
      `;
    }
    
    function formatEventTime() {
      const d = new Date();
      return `Today • ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
    
    function addPoints(amount) {
      state.currentUser.points += amount;
      showPointsPopup(amount);
      updateRank();
      renderApp();
    }
    
    function showPointsPopup(amount) {
      const popup = document.createElement('div');
      popup.className = 'nv-points-popup';
      popup.textContent = `+${amount} pts`;
      popup.style.right = '200px';
      popup.style.top = '50%';
      document.body.appendChild(popup);
      setTimeout(() => popup.remove(), 1500);
    }
    
    function showFloatingEmoji(emoji) {
      const el = document.createElement('div');
      el.className = 'nv-floating-emoji';
      el.textContent = emoji;
      el.style.right = `${Math.random() * 200 + 100}px`;
      el.style.bottom = '200px';
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 2000);
    }
    
    function updateRank() {
      const all = [...state.participants, state.currentUser].sort((a, b) => b.points - a.points);
      state.currentUser.rank = all.findIndex(p => p.id === state.currentUser.id) + 1;
    }
    
    function triggerConfetti() {
      const container = document.createElement('div');
      container.className = 'nv-confetti';
      document.body.appendChild(container);
      
      const emojis = ['🎉', '✨', '🌟', '💫', '🎊'];
      for (let i = 0; i < 30; i++) {
        const piece = document.createElement('div');
        piece.className = 'nv-confetti-piece';
        piece.textContent = emojis[Math.floor(Math.random() * emojis.length)];
        piece.style.left = `${Math.random() * 100}%`;
        piece.style.animationDelay = `${Math.random() * 2}s`;
        container.appendChild(piece);
      }
      setTimeout(() => container.remove(), 5000);
    }
    
    // ============================================
    // EVENT LISTENERS
    // ============================================
    
    function setupEventListeners() {
      // Tabs
      document.querySelectorAll('.nv-tab').forEach(tab => {
        tab.onclick = () => {
          state.phase = tab.dataset.phase;
          renderApp();
          if (state.phase === 'post') setTimeout(triggerConfetti, 500);
        };
      });
      
      // Go Live
      const goLive = document.getElementById('nv-go-live');
      if (goLive) goLive.onclick = () => {
        state.phase = 'live';
        addPoints(50);
      };
      
      // End Meeting
      const endMeeting = document.getElementById('nv-end-meeting');
      if (endMeeting) endMeeting.onclick = () => {
        state.phase = 'post';
        renderApp();
        setTimeout(triggerConfetti, 500);
      };
      
      // Save Goals
      const saveGoals = document.getElementById('nv-save-goals');
      if (saveGoals) saveGoals.onclick = () => {
        const input = document.getElementById('nv-goals-input');
        if (input?.value.trim()) {
          state.goals = input.value.trim();
          addPoints(20);
          saveGoals.textContent = '✅ Saved!';
          saveGoals.disabled = true;
        }
      };
      
      // Add Question
      const addQ = document.getElementById('nv-add-question');
      if (addQ) addQ.onclick = () => {
        const input = document.getElementById('nv-question-input');
        if (input?.value.trim()) {
          state.preparedQuestions.push({ text: input.value.trim(), asked: false });
          addPoints(15);
          input.value = '';
          renderApp();
        }
      };
      
      // Poll voting
      document.querySelectorAll('.nv-poll-option').forEach(opt => {
        opt.onclick = () => {
          const pollId = opt.dataset.pollId;
          if (!state.votedPolls.includes(pollId)) {
            state.votedPolls.push(pollId);
            state.currentUser.selectedOption = opt.dataset.optionId;
            addPoints(15);
          }
        };
      });
      
      // Reactions
      document.querySelectorAll('.nv-reaction-btn').forEach(btn => {
        btn.onclick = () => {
          if (state.currentUser.reactions.length < 10) {
            state.currentUser.reactions.push({ emoji: btn.dataset.emoji });
            showFloatingEmoji(btn.dataset.emoji);
            addPoints(5);
          }
        };
      });
      
      // Live Question
      const askLive = document.getElementById('nv-ask-live-question');
      if (askLive) askLive.onclick = () => {
        const input = document.getElementById('nv-live-question-input');
        if (input?.value.trim()) {
          state.currentUser.questionsAsked.push({ text: input.value.trim() });
          addPoints(25);
          input.value = '';
          alert('✅ Question submitted!');
        }
      };
      
      // Rating
      document.querySelectorAll('.nv-rating-btn').forEach(btn => {
        btn.onclick = () => {
          if (!state.currentUser.rating) {
            state.currentUser.rating = parseInt(btn.dataset.rating);
            addPoints(10);
          }
        };
      });
      
      // AI Chat
      const aiSend = document.getElementById('nv-ai-send');
      if (aiSend) aiSend.onclick = () => {
        const input = document.getElementById('nv-ai-input');
        if (input?.value.trim()) {
          const q = input.value.trim().toLowerCase();
          state.aiMessages.push({ role: 'user', content: input.value.trim() });
          
          // Find response
          let response = MOCK.aiResponses.default;
          for (const [key, val] of Object.entries(MOCK.aiResponses)) {
            if (q.includes(key)) { response = val; break; }
          }
          
          state.aiMessages.push({ role: 'assistant', content: response });
          addPoints(10);
          input.value = '';
          renderApp();
        }
      };
      
      // Share Slack
      const shareSlack = document.getElementById('nv-share-slack');
      if (shareSlack) shareSlack.onclick = () => {
        alert(`📤 Shared to Slack!\n\n"I earned ${state.currentUser.points} pts at Tech Night! 🎮"`);
      };
    }
    
    console.log('🎮 Nybble Vibe: App initialized!');
  }
})();
