// ============================================
// NYBBLE VIBE - Extension Popup
// Connects to dashboard via API (mocked)
// ============================================

// State
const state = {
  loading: true,
  event: null,          // Current event from DB
  user: null,           // Current user
  polls: [],            // Polls for this event
  leaderboard: [],      // Leaderboard
  attendance: null,     // User's attendance record
  userVotes: [],        // User's poll votes
  userReactions: [],    // User's reactions
  aiMessages: [],       // AI chat history
  currentUrl: '',       // Current tab URL
  points: 0,            // User's total points in this event
  badges: []            // Earned badges
};

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', async () => {
  console.log('🎮 Nybble Vibe: Popup opened');
  
  try {
    // Get current tab URL
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    state.currentUrl = tab?.url || '';
    console.log('🎮 Current URL:', state.currentUrl);
    
    // Check if mock data loaded
    if (!window.NYBBLE_DB || !window.NYBBLE_API) {
      console.error('🎮 Mock data not loaded!');
      renderError('Error: Mock data not loaded');
      return;
    }
    console.log('🎮 Mock data loaded:', window.NYBBLE_DB.events.length, 'events');
    
    // Load user from storage
    await loadUserData();
    console.log('🎮 User loaded:', state.user);
    
    // Try to find event matching current URL
    await findEventForCurrentUrl();
    
  } catch (error) {
    console.error('🎮 Init error:', error);
    state.loading = false;
    renderError('Error: ' + error.message);
  }
});

async function loadUserData() {
  // In real app, this comes from auth/dashboard
  if (!window.NYBBLE_DB?.currentUser) {
    console.error('🎮 No currentUser in DB!');
    state.user = { id: 'guest', name: 'Guest', avatar: '👤' };
  } else {
    state.user = window.NYBBLE_DB.currentUser;
  }
  
  // Load saved state
  try {
    const saved = await chrome.storage.local.get(['nybbleUserPoints', 'nybbleBadges']);
    state.points = saved.nybbleUserPoints || 0;
    state.badges = saved.nybbleBadges || [];
  } catch (e) {
    console.log('Could not load saved state:', e);
  }
}

async function findEventForCurrentUrl() {
  state.loading = true;
  render();
  
  // Check if we're on a Google Meet page
  if (!state.currentUrl.includes('meet.google.com')) {
    console.log('🎮 Not on Google Meet');
    state.loading = false;
    state.event = null;
    render();
    return;
  }
  
  console.log('🎮 On Google Meet, searching for event...');
  
  // Try to find event in database
  try {
    const event = await window.NYBBLE_API.findEventByUrl(state.currentUrl);
    console.log('🎮 Event found:', event);
    
    if (event) {
      state.event = event;
      
      // Mark attendance
      try {
        const attResult = await window.NYBBLE_API.markAttendance(event.id, state.user.id);
        console.log('🎮 Attendance result:', attResult);
        if (attResult.isNew) {
          state.points += attResult.points;
          state.attendance = { joinedAt: new Date().toISOString(), points: attResult.points };
        }
      } catch (attError) {
        console.error('🎮 Attendance error:', attError);
      }
      
      // Load event data
      await loadEventData(event.id);
    } else {
      console.log('🎮 No event found for this URL');
    }
  } catch (findError) {
    console.error('🎮 Find event error:', findError);
  }
  
  state.loading = false;
  render();
  saveUserData();
}

async function loadEventData(eventId) {
  // Load polls
  state.polls = await window.NYBBLE_API.getPolls(eventId);
  
  // Load leaderboard
  state.leaderboard = await window.NYBBLE_API.getLeaderboard(eventId);
  
  // Update badge count
  updateBadge();
}

async function saveUserData() {
  try {
    await chrome.storage.local.set({
      nybbleUserPoints: state.points,
      nybbleBadges: state.badges
    });
  } catch (e) {
    console.log('Could not save state');
  }
}

function updateBadge() {
  try {
    const activePoll = state.polls.find(p => p.status === 'active');
    const hasUnvoted = activePoll && !state.userVotes.includes(activePoll.id);
    
    if (hasUnvoted) {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#F36F25' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch (e) {}
}

// ============================================
// RENDERING
// ============================================

function render() {
  const app = document.getElementById('app');
  
  if (state.loading) {
    app.innerHTML = renderLoading();
    return;
  }
  
  if (!state.event) {
    app.innerHTML = renderNoEvent();
    setupEventCardListeners();
    return;
  }
  
  app.innerHTML = `
    ${renderHeader()}
    ${renderEventInfo()}
    ${renderPointsBar()}
    ${renderPhaseContent()}
    ${renderFooter()}
  `;
  
  setupListeners();
}

function setupEventCardListeners() {
  document.querySelectorAll('.event-card').forEach(card => {
    card.addEventListener('click', (e) => {
      // Don't trigger if clicking on the link itself
      if (e.target.tagName === 'A') return;
      
      const url = card.dataset.url;
      if (url) {
        chrome.tabs.create({ url });
      }
    });
    
    // Add hover effect
    card.addEventListener('mouseenter', () => {
      card.style.borderColor = 'rgba(243, 111, 37, 0.5)';
      card.style.transform = 'translateY(-2px)';
      card.style.transition = 'all 0.2s ease';
    });
    
    card.addEventListener('mouseleave', () => {
      card.style.borderColor = '';
      card.style.transform = '';
    });
  });
}

function renderLoading() {
  return `
    <div class="loading">
      <div class="spinner"></div>
      <p>Buscando evento...</p>
    </div>
  `;
}

function renderNoEvent() {
  const isOnMeet = state.currentUrl.includes('meet.google.com');
  
  return `
    <div class="header">
      <div class="logo">
        <img src="https://go.nybblegroup.com/web/image/website/1/logo/Nybble%20Go%20Website?unique=59c6826" 
             alt="Nybble" class="logo-img" onerror="this.style.display='none'">
        <span class="logo-text">NYBBLE VIBE</span>
      </div>
    </div>
    
    <div style="padding: 40px 20px; text-align: center;">
      ${isOnMeet ? `
        <div style="font-size: 48px; margin-bottom: 16px;">🔍</div>
        <h3 style="color: #F2F2F2; margin-bottom: 8px;">Evento no encontrado</h3>
        <p style="color: #6E767D; font-size: 13px; margin-bottom: 24px;">
          Este Google Meet no está registrado en el sistema.
        </p>
        <div class="card" style="text-align: left; padding: 16px;">
          <p style="font-size: 12px; color: #6E767D; margin-bottom: 12px;">
            <strong style="color: #2B89C1;">URL detectada:</strong><br>
            <code style="font-size: 11px; word-break: break-all;">${state.currentUrl}</code>
          </p>
          <p style="font-size: 11px; color: #6E767D;">
            Contacta al organizador para que registre este evento en el dashboard.
          </p>
        </div>
      ` : `
        <div style="font-size: 48px; margin-bottom: 16px;">📹</div>
        <h3 style="color: #F2F2F2; margin-bottom: 8px;">Abre Google Meet</h3>
        <p style="color: #6E767D; font-size: 13px; margin-bottom: 24px;">
          Únete a una reunión registrada para participar.
        </p>
        <a href="https://calendar.google.com/calendar/" target="_blank" class="btn btn-primary">
          Ir a Google Meet
        </a>
      `}
    </div>
    
    <div style="padding: 0 20px;">
      <div class="section-title">📅 Próximos eventos</div>
      ${window.NYBBLE_DB.events.filter(e => e.status === 'active').map(e => `
        <div class="card event-card" style="margin-bottom: 10px; cursor: pointer;" data-url="${e.meetingUrl}">
          <div style="font-weight: 600; color: #F2F2F2;">${e.title}</div>
          <div style="font-size: 12px; color: #6E767D; margin-top: 4px;">
            ${new Date(e.scheduledStart).toLocaleDateString()} • ${e.phase.toUpperCase()}
          </div>
          <a href="${e.meetingUrl}" target="_blank" 
             style="font-size: 11px; color: #2B89C1; margin-top: 4px; display: block; text-decoration: none;"
             onclick="event.stopPropagation();">
            🔗 ${e.meetingUrl.replace('https://meet.google.com/', '')}
          </a>
        </div>
      `).join('')}
    </div>
    
    ${renderFooter()}
  `;
}

function renderHeader() {
  const phaseLabels = {
    pre: { text: '⏳ PRE', class: 'pre' },
    live: { text: '🔴 LIVE', class: 'live' },
    post: { text: '✅ COMPLETADO', class: 'post' }
  };
  
  const phase = phaseLabels[state.event.phase];
  
  return `
    <div class="header">
      <div class="logo">
        <img src="https://go.nybblegroup.com/web/image/website/1/logo/Nybble%20Go%20Website?unique=59c6826" 
             alt="Nybble" class="logo-img" onerror="this.style.display='none'" width="100%" height="auto">
        <span class="logo-text">NYBBLE VIBE</span>
      </div>
      <span class="phase-badge ${phase.class}">${phase.text}</span>
    </div>
  `;
}

function renderEventInfo() {
  const e = state.event;
  const startTime = new Date(e.scheduledStart).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  return `
    <div class="event-info">
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="font-size: 24px;">${e.host.avatar}</span>
        <div>
          <div class="event-title">${e.title}</div>
          <div class="event-time">
            📅 Hoy • ${startTime} • Host: ${e.host.name}
          </div>
        </div>
      </div>
    </div>
    
    ${state.attendance ? `
      <div class="success-card" style="margin: 12px 16px;">
        <span class="success-icon">✅</span>
        <div class="success-text">
          <div class="success-title">¡Asistencia registrada!</div>
          <div class="success-subtitle">+50 pts • ${new Date(state.attendance.joinedAt).toLocaleTimeString()}</div>
        </div>
      </div>
    ` : ''}
  `;
}

function renderPointsBar() {
  // Find user in leaderboard
  const userInLeaderboard = state.leaderboard.find(l => l.odUserId === state.user.id);
  const rank = userInLeaderboard ? state.leaderboard.indexOf(userInLeaderboard) + 1 : '-';
  
  return `
    <div class="stats-card">
      <div class="stat">
        <div class="stat-value">⭐ ${state.points}</div>
        <div class="stat-label">Puntos</div>
      </div>
      <div class="stat">
        <div class="stat-value">#${rank}</div>
        <div class="stat-label">Ranking</div>
      </div>
      <div class="stat">
        <div class="stat-value">🏆 ${state.badges.length}</div>
        <div class="stat-label">Badges</div>
      </div>
    </div>
  `;
}

function renderPhaseContent() {
  switch (state.event.phase) {
    case 'pre': return renderPrePhase();
    case 'live': return renderLivePhase();
    case 'post': return renderPostPhase();
    default: return '';
  }
}

// ============================================
// PRE PHASE
// ============================================

function renderPrePhase() {
  return `
    <div class="section">
      <h3 class="section-title">📋 Agenda</h3>
      <div class="card">
        ${state.event.agenda.map(item => `
          <div class="agenda-item">
            <span class="agenda-time">${item.time}</span>
            <span class="agenda-title">${item.title}</span>
            <span class="agenda-presenter">${item.presenter}</span>
          </div>
        `).join('')}
      </div>
    </div>
    
    <div class="section">
      <h3 class="section-title">🎯 Tu objetivo para esta reunión</h3>
      <div class="card">
        <textarea class="textarea" id="goal-input" placeholder="¿Qué quieres aprender o lograr?"></textarea>
        <button class="btn btn-primary" id="save-goal" style="margin-top: 10px;">
          Guardar objetivo (+20 pts)
        </button>
      </div>
    </div>
    
    <div class="section">
      <h3 class="section-title">❓ Prepara tus preguntas</h3>
      <div class="card">
        <div style="display: flex; gap: 6px;">
          <input type="text" class="input" id="question-input" placeholder="Escribe una pregunta...">
          <button class="btn btn-secondary btn-small" id="add-question">+</button>
        </div>
        <p style="font-size: 11px; color: #6E767D; margin-top: 8px;">
          Las preguntas preparadas ganan +15 pts cada una
        </p>
      </div>
    </div>
    
    <div class="section">
      <h3 class="section-title">👥 Participantes esperados</h3>
      <div class="card">
        <div class="attendees">
          ${state.leaderboard.slice(0, 6).map(p => `
            <span class="attendee" title="${p.name}">${p.avatar}</span>
          `).join('')}
          ${state.leaderboard.length > 6 ? `
            <span class="attendee-more">+${state.leaderboard.length - 6}</span>
          ` : ''}
        </div>
      </div>
    </div>
  `;
}

// ============================================
// LIVE PHASE
// ============================================

function renderLivePhase() {
  const activePoll = state.polls.find(p => p.status === 'active');
  const hasVoted = activePoll && state.userVotes.includes(activePoll.id);
  
  return `
    ${activePoll ? `
      <div class="section">
        <h3 class="section-title">📊 Encuesta activa</h3>
        <div class="poll">
          <div class="poll-question">${activePoll.question}</div>
          ${activePoll.options.map(opt => {
            const totalVotes = activePoll.options.reduce((sum, o) => sum + o.votes, 0);
            const percent = totalVotes > 0 ? Math.round((opt.votes / totalVotes) * 100) : 0;
            return `
              <div class="poll-option ${state.selectedOption === opt.id ? 'selected' : ''}" 
                   data-poll-id="${activePoll.id}" 
                   data-option-id="${opt.id}"
                   ${hasVoted ? 'data-voted="true"' : ''}>
                ${hasVoted ? `<div class="poll-option-bar" style="width: ${percent}%;"></div>` : ''}
                <div class="poll-option-content">
                  <div class="poll-option-radio"></div>
                  <span class="poll-option-text">${opt.text}</span>
                  ${hasVoted ? `<span class="poll-option-percent">${percent}%</span>` : ''}
                </div>
              </div>
            `;
          }).join('')}
          <div class="poll-stats">
            <span>${activePoll.options.reduce((sum, o) => sum + o.votes, 0)} votos</span>
            <span>${hasVoted ? '✅ Votado' : `+${activePoll.points} pts`}</span>
          </div>
        </div>
      </div>
    ` : `
      <div class="section">
        <div class="card" style="text-align: center; padding: 20px;">
          <div style="font-size: 32px; margin-bottom: 8px;">📊</div>
          <p style="color: #6E767D; font-size: 13px;">No hay encuestas activas</p>
        </div>
      </div>
    `}
    
    <div class="section">
      <h3 class="section-title">⚡ Reacciones rápidas</h3>
      <div class="card">
        <div class="reactions">
          ${['🔥', '👏', '💡', '🤔', '❤️', '🚀', '😂', '🎯'].map(emoji => `
            <button class="reaction-btn" data-emoji="${emoji}">${emoji}</button>
          `).join('')}
        </div>
        <p style="font-size: 11px; color: #6E767D; text-align: center; margin-top: 8px;">
          Reacciones: ${state.userReactions.length}/${state.event.settings.maxReactionsPerUser} (+5 pts c/u)
        </p>
      </div>
    </div>
    
    <div class="section">
      <h3 class="section-title">🙋 Hacer pregunta</h3>
      <div class="card">
        <div style="display: flex; gap: 6px;">
          <input type="text" class="input" id="live-question" placeholder="Pregunta anónima...">
          <button class="btn btn-primary btn-small" id="submit-question">Enviar</button>
        </div>
        <p style="font-size: 11px; color: #6E767D; margin-top: 8px;">
          +25 pts por pregunta
        </p>
      </div>
    </div>
    
    <div class="section">
      <h3 class="section-title">🏆 Leaderboard en vivo</h3>
      ${renderLeaderboard()}
    </div>
  `;
}

// ============================================
// POST PHASE
// ============================================

function renderPostPhase() {
  return `
    <div class="section">
      <h3 class="section-title">⭐ Califica esta sesión</h3>
      <div class="card">
        <div class="rating">
          ${['😫', '😕', '😐', '🙂', '🤩'].map((emoji, i) => `
            <button class="rating-btn ${state.userRating === i + 1 ? 'selected' : ''}" 
                    data-rating="${i + 1}">${emoji}</button>
          `).join('')}
        </div>
        <p style="font-size: 11px; color: #6E767D; text-align: center; margin-top: 8px;">
          +10 pts por calificar
        </p>
      </div>
    </div>
    
    <div class="section">
      <h3 class="section-title">🤖 Pregunta sobre la reunión</h3>
      <div class="ai-chat">
        <div class="ai-header">
          <span class="ai-icon">🤖</span>
          <span class="ai-title">AI Meeting Assistant</span>
        </div>
        <div class="ai-messages" id="ai-messages">
          ${state.aiMessages.length === 0 ? `
            <div class="ai-message assistant">
              Pregúntame sobre la reunión:<br>
              • "action items"<br>
              • "costos"<br>
              • "next steps"
            </div>
          ` : state.aiMessages.map(m => `
            <div class="ai-message ${m.role}">${m.content}</div>
          `).join('')}
        </div>
        <div class="ai-input-group">
          <input type="text" class="input" id="ai-input" placeholder="Pregunta...">
          <button class="btn btn-primary" id="ai-send">Ask</button>
        </div>
      </div>
    </div>
    
    <div class="section">
      <h3 class="section-title">🏆 Resultados finales</h3>
      <div class="results-card">
        <div class="results-avatar">${state.user.avatar}</div>
        <div class="results-points">⭐ ${state.points} pts</div>
        <div class="results-rank">Este evento</div>
        
        <div class="badges">
          ${state.badges.length > 0 ? 
            state.badges.map(id => {
              const badge = window.NYBBLE_DB.badges[id];
              return badge ? `<span class="badge earned">${badge.icon} ${badge.name}</span>` : '';
            }).join('') : 
            '<span class="badge">¡Sigue participando!</span>'
          }
        </div>
      </div>
    </div>
    
    <div class="section">
      <h3 class="section-title">🏆 Leaderboard final</h3>
      ${renderLeaderboard()}
    </div>
  `;
}

function renderLeaderboard() {
  return `
    <div class="card" style="padding: 8px;">
      ${state.leaderboard.slice(0, 5).map((p, i) => {
        const rank = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;
        const isMe = p.odUserId === state.user.id;
        return `
          <div class="leaderboard-item ${isMe ? 'current-user' : ''}">
            <span class="leaderboard-rank">${rank}</span>
            <span class="leaderboard-avatar">${p.avatar}</span>
            <span class="leaderboard-name">${p.name}</span>
            <span class="leaderboard-points">${p.points}</span>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function renderFooter() {
  return `
    <div class="footer">
      <span class="footer-text">Made with 💜 by <a href="#" class="footer-link">Nybble Group</a></span>
    </div>
  `;
}

function renderError(message) {
  document.getElementById('app').innerHTML = `
    <div style="padding: 40px 20px; text-align: center;">
      <div style="font-size: 48px; margin-bottom: 16px;">❌</div>
      <h3 style="color: #EF4444;">${message}</h3>
    </div>
  `;
}

// ============================================
// EVENT HANDLERS
// ============================================

function setupListeners() {
  // Poll voting
  document.querySelectorAll('.poll-option:not([data-voted])').forEach(opt => {
    opt.onclick = async () => {
      const pollId = opt.dataset.pollId;
      const optionId = opt.dataset.optionId;
      
      if (!state.userVotes.includes(pollId)) {
        const result = await window.NYBBLE_API.submitVote(pollId, state.user.id, optionId);
        if (result.success) {
          state.userVotes.push(pollId);
          state.selectedOption = optionId;
          addPoints(result.points);
          updateBadge();
          render();
        }
      }
    };
  });
  
  // Reactions
  document.querySelectorAll('.reaction-btn').forEach(btn => {
    btn.onclick = async () => {
      if (state.userReactions.length < state.event.settings.maxReactionsPerUser) {
        const emoji = btn.dataset.emoji;
        const result = await window.NYBBLE_API.submitReaction(state.event.id, state.user.id, emoji);
        if (result.success) {
          state.userReactions.push(emoji);
          addPoints(result.points);
          showFloatingEmoji(emoji);
        }
      }
    };
  });
  
  // Submit question (live)
  const submitQ = document.getElementById('submit-question');
  if (submitQ) {
    submitQ.onclick = async () => {
      const input = document.getElementById('live-question');
      if (input?.value.trim()) {
        const result = await window.NYBBLE_API.submitQuestion(
          state.event.id, 
          state.user.id, 
          input.value.trim(),
          true // anonymous
        );
        if (result.success) {
          addPoints(result.points);
          input.value = '';
          showToast('✅ Pregunta enviada');
        }
      }
    };
  }
  
  // Rating
  document.querySelectorAll('.rating-btn').forEach(btn => {
    btn.onclick = async () => {
      if (!state.userRating) {
        const rating = parseInt(btn.dataset.rating);
        const result = await window.NYBBLE_API.submitRating(state.event.id, state.user.id, rating);
        if (result.success) {
          state.userRating = rating;
          addPoints(result.points);
          render();
        }
      }
    };
  });
  
  // AI Chat
  const aiSend = document.getElementById('ai-send');
  if (aiSend) {
    aiSend.onclick = async () => {
      const input = document.getElementById('ai-input');
      if (input?.value.trim()) {
        state.aiMessages.push({ role: 'user', content: input.value.trim() });
        render();
        
        const result = await window.NYBBLE_API.askAI(state.event.id, input.value.trim());
        state.aiMessages.push({ role: 'assistant', content: result.response });
        addPoints(10);
        input.value = '';
        render();
        
        // Scroll to bottom
        setTimeout(() => {
          const msgs = document.getElementById('ai-messages');
          if (msgs) msgs.scrollTop = msgs.scrollHeight;
        }, 100);
      }
    };
  }
  
  // Save goal
  const saveGoal = document.getElementById('save-goal');
  if (saveGoal) {
    saveGoal.onclick = () => {
      const input = document.getElementById('goal-input');
      if (input?.value.trim()) {
        addPoints(20);
        saveGoal.textContent = '✅ Guardado';
        saveGoal.disabled = true;
      }
    };
  }
  
  // Add prepared question
  const addQ = document.getElementById('add-question');
  if (addQ) {
    addQ.onclick = () => {
      const input = document.getElementById('question-input');
      if (input?.value.trim()) {
        addPoints(15);
        input.value = '';
        showToast('✅ Pregunta preparada (+15 pts)');
      }
    };
  }
}

// ============================================
// HELPERS
// ============================================

function addPoints(amount) {
  state.points += amount;
  showPointsPopup(amount);
  saveUserData();
}

function showPointsPopup(amount) {
  const popup = document.createElement('div');
  popup.className = 'points-popup';
  popup.textContent = `+${amount}`;
  popup.style.left = '50%';
  popup.style.top = '30%';
  popup.style.transform = 'translateX(-50%)';
  document.body.appendChild(popup);
  setTimeout(() => popup.remove(), 1500);
}

function showFloatingEmoji(emoji) {
  const el = document.createElement('div');
  el.className = 'floating-emoji';
  el.textContent = emoji;
  el.style.left = `${Math.random() * 60 + 20}%`;
  el.style.bottom = '100px';
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1500);
}

function showToast(message) {
  const toast = document.createElement('div');
  toast.style.cssText = `
    position: fixed;
    bottom: 80px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(16, 185, 129, 0.9);
    color: white;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 12px;
    z-index: 9999;
    animation: fadeInOut 2s ease;
  `;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2000);
}

console.log('🎮 Nybble Vibe: Popup loaded');