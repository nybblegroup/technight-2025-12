// ============================================
// NYBBLE VIBE - Main Application
// ============================================

(() => {
  // Get mock data
  const MOCK = window.NYBBLE_MOCK;
  
  // App State
  const state = {
    phase: 'pre', // 'pre' | 'live' | 'post'
    event: { ...MOCK.event },
    currentUser: { ...MOCK.currentUser },
    polls: [...MOCK.polls],
    participants: [...MOCK.participants],
    votedPolls: [],
    aiMessages: [],
    preparedQuestions: [],
    goals: '',
  };
  
  // Initialize app
  function init() {
    console.log('🎮 Nybble Vibe App: Initializing...');
    renderApp();
    setupEventListeners();
  }
  
  // Main render function
  function renderApp() {
    const content = document.getElementById('nv-content');
    if (!content) return;
    
    content.innerHTML = `
      ${renderEventInfo()}
      ${renderStats()}
      ${renderTabs()}
      <div id="nv-tab-content">
        ${renderCurrentPhase()}
      </div>
    `;
    
    // Re-setup event listeners after render
    setTimeout(setupEventListeners, 0);
  }
  
  // Render event info header
  function renderEventInfo() {
    const phaseLabels = {
      pre: '⏳ PRE-EVENT',
      live: '🔴 LIVE',
      post: '✅ COMPLETED'
    };
    
    return `
      <div class="nv-event-info">
        <span class="nv-phase-badge ${state.phase}">${phaseLabels[state.phase]}</span>
        <h2 class="nv-event-title">${state.event.title}</h2>
        <div class="nv-event-time">
          <span>📅</span>
          <span>${formatEventTime()}</span>
        </div>
      </div>
    `;
  }
  
  // Render stats card
  function renderStats() {
    return `
      <div class="nv-stats-card">
        <div class="nv-stat">
          <div class="nv-stat-value">⭐ ${state.currentUser.points}</div>
          <div class="nv-stat-label">Points</div>
        </div>
        <div class="nv-stat">
          <div class="nv-stat-value">#${state.currentUser.rank || '–'}</div>
          <div class="nv-stat-label">Rank</div>
        </div>
        <div class="nv-stat">
          <div class="nv-stat-value">🔥 ${state.currentUser.streak}</div>
          <div class="nv-stat-label">Streak</div>
        </div>
      </div>
    `;
  }
  
  // Render phase tabs
  function renderTabs() {
    return `
      <div class="nv-tabs">
        <button class="nv-tab ${state.phase === 'pre' ? 'active' : ''}" data-phase="pre">
          📋 Prepare
        </button>
        <button class="nv-tab ${state.phase === 'live' ? 'active' : ''}" data-phase="live">
          ⚡ Live
        </button>
        <button class="nv-tab ${state.phase === 'post' ? 'active' : ''}" data-phase="post">
          📊 Results
        </button>
      </div>
    `;
  }
  
  // Render current phase content
  function renderCurrentPhase() {
    switch (state.phase) {
      case 'pre': return renderPrePhase();
      case 'live': return renderLivePhase();
      case 'post': return renderPostPhase();
      default: return '';
    }
  }
  
  // ============================================
  // PRE-MEETING PHASE
  // ============================================
  
  function renderPrePhase() {
    return `
      <!-- Agenda Section -->
      <div class="nv-section">
        <h3 class="nv-section-title">📋 Agenda</h3>
        <div class="nv-card">
          ${state.event.agenda.map((item, i) => `
            <div class="nv-agenda-item">
              <span class="nv-agenda-time">${item.duration}m</span>
              <span class="nv-agenda-title">${item.title}</span>
              <span class="nv-agenda-presenter">${item.presenter}</span>
            </div>
          `).join('')}
        </div>
      </div>
      
      <!-- Set Goals Section -->
      <div class="nv-section">
        <h3 class="nv-section-title">🎯 Set Your Goals</h3>
        <div class="nv-card">
          <p style="font-size: 13px; color: #A1A1AA; margin: 0 0 12px;">
            What do you want to get from this meeting?
          </p>
          <textarea 
            class="nv-textarea" 
            id="nv-goals-input"
            placeholder="E.g., Learn about AI integration, understand the roadmap..."
          >${state.goals}</textarea>
          <button class="nv-btn nv-btn-primary" id="nv-save-goals" style="margin-top: 12px;">
            Save Goals (+20 pts)
          </button>
        </div>
      </div>
      
      <!-- Prepare Questions Section -->
      <div class="nv-section">
        <h3 class="nv-section-title">❓ Prepare Questions</h3>
        <div class="nv-card">
          <div id="nv-prepared-questions">
            ${state.preparedQuestions.length === 0 ? `
              <p style="font-size: 13px; color: #71717A; margin: 0 0 12px;">
                No questions yet. Add some to ask during the meeting!
              </p>
            ` : state.preparedQuestions.map((q, i) => `
              <div class="nv-question-item">
                <div class="nv-question-checkbox ${q.asked ? 'checked' : ''}" data-index="${i}"></div>
                <span class="nv-question-text">${q.text}</span>
              </div>
            `).join('')}
          </div>
          <div style="display: flex; gap: 8px; margin-top: 12px;">
            <input 
              type="text" 
              class="nv-input" 
              id="nv-question-input"
              placeholder="Type a question..."
            />
            <button class="nv-btn nv-btn-secondary" id="nv-add-question" style="width: auto; padding: 12px 16px;">
              +
            </button>
          </div>
        </div>
      </div>
      
      <!-- Attendees Section -->
      <div class="nv-section">
        <h3 class="nv-section-title">👥 Who's Joining (${state.participants.length})</h3>
        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
          ${state.participants.slice(0, 8).map(p => `
            <div style="font-size: 28px; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));" title="${p.name}">
              ${p.avatar}
            </div>
          `).join('')}
          ${state.participants.length > 8 ? `
            <div style="font-size: 14px; color: #71717A; display: flex; align-items: center;">
              +${state.participants.length - 8} more
            </div>
          ` : ''}
        </div>
      </div>
      
      <!-- Join Live Button -->
      <div class="nv-section">
        <button class="nv-btn nv-btn-primary" id="nv-go-live">
          🚀 Start Live Experience
        </button>
      </div>
    `;
  }
  
  // ============================================
  // LIVE PHASE
  // ============================================
  
  function renderLivePhase() {
    const activePoll = state.polls.find(p => p.status === 'active');
    
    return `
      <!-- Attendance Confirmation -->
      <div class="nv-section">
        <div class="nv-card" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(16, 185, 129, 0.05)); border-color: rgba(16, 185, 129, 0.3);">
          <div style="display: flex; align-items: center; gap: 12px;">
            <span style="font-size: 32px;">✅</span>
            <div>
              <div style="font-size: 14px; font-weight: 600; color: #10B981;">Attendance Tracked!</div>
              <div style="font-size: 12px; color: #71717A;">You joined at ${new Date().toLocaleTimeString()}</div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Active Poll -->
      ${activePoll ? `
        <div class="nv-section">
          <h3 class="nv-section-title">📊 Active Poll</h3>
          <div class="nv-poll">
            <div class="nv-poll-question">${activePoll.question}</div>
            <div id="nv-poll-options">
              ${activePoll.options.map(opt => {
                const percentage = Math.round((opt.votes / activePoll.totalVotes) * 100) || 0;
                const isVoted = state.votedPolls.includes(activePoll.id);
                const isSelected = state.currentUser.selectedOption === opt.id;
                return `
                  <div class="nv-poll-option ${isSelected ? 'selected' : ''}" 
                       data-poll-id="${activePoll.id}" 
                       data-option-id="${opt.id}"
                       style="position: relative; overflow: hidden; ${isVoted ? 'pointer-events: none;' : ''}">
                    ${isVoted ? `<div class="nv-poll-option-bar" style="width: ${percentage}%;"></div>` : ''}
                    <div class="nv-poll-option-radio"></div>
                    <span class="nv-poll-option-text">${opt.text}</span>
                    ${isVoted ? `<span style="color: #6366F1; font-weight: 600;">${percentage}%</span>` : ''}
                  </div>
                `;
              }).join('')}
            </div>
            <div class="nv-poll-stats">
              <span>${activePoll.totalVotes} votes</span>
              <span>${state.votedPolls.includes(activePoll.id) ? '✅ You voted!' : 'Vote to earn +15 pts'}</span>
            </div>
          </div>
        </div>
      ` : `
        <div class="nv-section">
          <div class="nv-card">
            <div class="nv-empty">
              <div class="nv-empty-icon">📊</div>
              <div class="nv-empty-text">No active poll right now</div>
            </div>
          </div>
        </div>
      `}
      
      <!-- Quick Reactions -->
      <div class="nv-section">
        <h3 class="nv-section-title">⚡ Quick Reactions</h3>
        <div class="nv-card">
          <p style="font-size: 12px; color: #71717A; margin: 0 0 12px; text-align: center;">
            Tap to react! (+5 pts each, max 10)
          </p>
          <div class="nv-reactions">
            ${['🔥', '👏', '💡', '🤔', '❤️', '🚀', '😂', '🎯'].map(emoji => `
              <button class="nv-reaction-btn" data-emoji="${emoji}">${emoji}</button>
            `).join('')}
          </div>
          <div style="text-align: center; margin-top: 12px; font-size: 12px; color: #71717A;">
            Reactions sent: ${state.currentUser.reactions.length}/10
          </div>
        </div>
      </div>
      
      <!-- Your Prepared Questions -->
      ${state.preparedQuestions.length > 0 ? `
        <div class="nv-section">
          <h3 class="nv-section-title">💬 Your Prepared Questions</h3>
          <div class="nv-card">
            ${state.preparedQuestions.map((q, i) => `
              <div class="nv-question-item">
                <div class="nv-question-checkbox ${q.asked ? 'checked' : ''}" data-index="${i}"></div>
                <span class="nv-question-text" style="${q.asked ? 'text-decoration: line-through; opacity: 0.5;' : ''}">${q.text}</span>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}
      
      <!-- Ask New Question -->
      <div class="nv-section">
        <h3 class="nv-section-title">🙋 Ask a Question</h3>
        <div class="nv-card">
          <div style="display: flex; gap: 8px;">
            <input 
              type="text" 
              class="nv-input" 
              id="nv-live-question-input"
              placeholder="Ask anonymously..."
            />
            <button class="nv-btn nv-btn-primary" id="nv-ask-live-question" style="width: auto; padding: 12px 16px;">
              Ask
            </button>
          </div>
          <p style="font-size: 11px; color: #71717A; margin: 8px 0 0; text-align: center;">
            Questions are anonymous • +25 pts
          </p>
        </div>
      </div>
      
      <!-- Mini Leaderboard -->
      <div class="nv-section">
        <h3 class="nv-section-title">🏆 Leaderboard</h3>
        ${renderLeaderboard(5)}
      </div>
      
      <!-- End Meeting Button -->
      <div class="nv-section">
        <button class="nv-btn nv-btn-secondary" id="nv-end-meeting">
          End Meeting → View Results
        </button>
      </div>
    `;
  }
  
  // ============================================
  // POST PHASE
  // ============================================
  
  function renderPostPhase() {
    return `
      <!-- Participation Summary -->
      <div class="nv-section">
        <h3 class="nv-section-title">📊 Your Participation</h3>
        <div class="nv-card">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
            <div style="text-align: center; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px;">
              <div style="font-size: 24px;">⏱️</div>
              <div style="font-size: 18px; font-weight: 700; color: #F4F4F5;">45 min</div>
              <div style="font-size: 11px; color: #71717A;">Attended</div>
            </div>
            <div style="text-align: center; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px;">
              <div style="font-size: 24px;">🗳️</div>
              <div style="font-size: 18px; font-weight: 700; color: #F4F4F5;">${state.votedPolls.length}/${state.polls.length}</div>
              <div style="font-size: 11px; color: #71717A;">Polls Voted</div>
            </div>
            <div style="text-align: center; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px;">
              <div style="font-size: 24px;">⚡</div>
              <div style="font-size: 18px; font-weight: 700; color: #F4F4F5;">${state.currentUser.reactions.length}</div>
              <div style="font-size: 11px; color: #71717A;">Reactions</div>
            </div>
            <div style="text-align: center; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px;">
              <div style="font-size: 24px;">💬</div>
              <div style="font-size: 18px; font-weight: 700; color: #F4F4F5;">${state.currentUser.questionsAsked.length}</div>
              <div style="font-size: 11px; color: #71717A;">Questions</div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Quick Rating -->
      <div class="nv-section">
        <h3 class="nv-section-title">⭐ Rate This Meeting</h3>
        <div class="nv-card">
          <div class="nv-rating">
            ${['😫', '😕', '😐', '🙂', '🤩'].map((emoji, i) => `
              <button class="nv-rating-btn ${state.currentUser.rating === i + 1 ? 'selected' : ''}" 
                      data-rating="${i + 1}">
                ${emoji}
              </button>
            `).join('')}
          </div>
          <p style="font-size: 12px; color: #71717A; margin: 12px 0 0; text-align: center;">
            ${state.currentUser.rating ? 'Thanks for rating! +10 pts' : 'Tap to rate (+10 pts)'}
          </p>
        </div>
      </div>
      
      <!-- Goal Achievement -->
      ${state.goals ? `
        <div class="nv-section">
          <h3 class="nv-section-title">🎯 Did You Achieve Your Goal?</h3>
          <div class="nv-card">
            <p style="font-size: 13px; color: #A1A1AA; margin: 0 0 12px;">
              "${state.goals}"
            </p>
            <div style="display: flex; gap: 8px;">
              <button class="nv-btn ${state.currentUser.goalAchieved === 'yes' ? 'nv-btn-primary' : 'nv-btn-secondary'}" 
                      data-goal="yes" style="flex: 1;">
                ✅ Yes
              </button>
              <button class="nv-btn ${state.currentUser.goalAchieved === 'partial' ? 'nv-btn-primary' : 'nv-btn-secondary'}" 
                      data-goal="partial" style="flex: 1;">
                🤏 Partial
              </button>
              <button class="nv-btn ${state.currentUser.goalAchieved === 'no' ? 'nv-btn-primary' : 'nv-btn-secondary'}" 
                      data-goal="no" style="flex: 1;">
                ❌ No
              </button>
            </div>
          </div>
        </div>
      ` : ''}
      
      <!-- AI Chat - Ask the Meeting -->
      <div class="nv-section">
        <h3 class="nv-section-title">🤖 Ask the Meeting</h3>
        <div class="nv-ai-chat">
          <div class="nv-ai-header">
            <span class="nv-ai-icon">🤖</span>
            <span class="nv-ai-title">AI-Powered Meeting Q&A</span>
          </div>
          <div class="nv-ai-messages" id="nv-ai-messages">
            ${state.aiMessages.length === 0 ? `
              <div class="nv-ai-message assistant">
                Hi! I've analyzed the meeting transcript. Ask me anything about what was discussed:
                <br><br>
                • "What were the action items?"<br>
                • "What was decided about X?"<br>
                • "Who is responsible for Y?"
              </div>
            ` : state.aiMessages.map(msg => `
              <div class="nv-ai-message ${msg.role}">${msg.content}</div>
            `).join('')}
          </div>
          <div class="nv-ai-input-group">
            <input 
              type="text" 
              class="nv-input" 
              id="nv-ai-input"
              placeholder="Ask about the meeting..."
            />
            <button class="nv-btn nv-btn-primary" id="nv-ai-send">
              Ask
            </button>
          </div>
        </div>
      </div>
      
      <!-- Final Score & Badges -->
      <div class="nv-section">
        <h3 class="nv-section-title">🏆 Final Results</h3>
        <div class="nv-card" style="text-align: center; background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(34, 211, 238, 0.1));">
          <div style="font-size: 48px; margin-bottom: 8px;">${state.currentUser.avatar}</div>
          <div style="font-size: 32px; font-weight: 700; color: #F4F4F5;">
            ⭐ ${state.currentUser.points} pts
          </div>
          <div style="font-size: 18px; color: #6366F1; margin-top: 4px;">
            Rank #${state.currentUser.rank}
          </div>
        </div>
        
        <!-- Badges -->
        <div style="margin-top: 16px;">
          <h4 style="font-size: 12px; color: #71717A; margin-bottom: 12px;">BADGES EARNED</h4>
          <div class="nv-badges">
            ${state.currentUser.badges.length > 0 ? 
              state.currentUser.badges.map(badgeId => {
                const badge = MOCK.badges[badgeId];
                return badge ? `
                  <div class="nv-badge earned">
                    <span class="nv-badge-icon">${badge.icon}</span>
                    <span>${badge.name}</span>
                  </div>
                ` : '';
              }).join('') : `
              <p style="font-size: 13px; color: #71717A;">Keep participating to earn badges!</p>
            `}
          </div>
        </div>
      </div>
      
      <!-- Full Leaderboard -->
      <div class="nv-section">
        <h3 class="nv-section-title">📊 Full Leaderboard</h3>
        ${renderLeaderboard(10)}
      </div>
      
      <!-- Feedback -->
      <div class="nv-section">
        <h3 class="nv-section-title">💬 Additional Feedback</h3>
        <div class="nv-card">
          <textarea 
            class="nv-textarea" 
            id="nv-feedback-input"
            placeholder="Any other thoughts? What would make this better?"
          ></textarea>
          <button class="nv-btn nv-btn-primary" id="nv-submit-feedback" style="margin-top: 12px;">
            Submit Feedback (+20 pts)
          </button>
        </div>
      </div>
      
      <!-- Share -->
      <div class="nv-section">
        <button class="nv-btn nv-btn-secondary" id="nv-share-slack">
          💬 Share Results on Slack
        </button>
      </div>
    `;
  }
  
  // ============================================
  // HELPER FUNCTIONS
  // ============================================
  
  function renderLeaderboard(limit = 5) {
    const sortedParticipants = [...state.participants, { ...state.currentUser, name: 'You', isCurrentUser: true }]
      .sort((a, b) => b.points - a.points)
      .slice(0, limit);
    
    return `
      <div class="nv-card" style="padding: 12px;">
        ${sortedParticipants.map((p, i) => {
          const rankDisplay = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;
          return `
            <div class="nv-leaderboard-item ${p.isCurrentUser ? 'current-user' : ''}">
              <span class="nv-leaderboard-rank ${i < 3 ? 'top-3' : ''}">${rankDisplay}</span>
              <span class="nv-leaderboard-avatar">${p.avatar}</span>
              <span class="nv-leaderboard-name">${p.name}</span>
              <span class="nv-leaderboard-points">${p.points} pts</span>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }
  
  function formatEventTime() {
    const start = new Date(state.event.startTime);
    const end = new Date(state.event.endTime);
    const options = { hour: '2-digit', minute: '2-digit' };
    return `${start.toLocaleDateString()} • ${start.toLocaleTimeString([], options)} - ${end.toLocaleTimeString([], options)}`;
  }
  
  function addPoints(amount, label) {
    state.currentUser.points += amount;
    showPointsPopup(amount, label);
    updateRank();
    renderApp();
  }
  
  function showPointsPopup(amount, label) {
    const popup = document.createElement('div');
    popup.className = 'nv-points-popup';
    popup.textContent = `+${amount} pts`;
    popup.style.right = '200px';
    popup.style.top = '50%';
    document.body.appendChild(popup);
    
    setTimeout(() => popup.remove(), 1500);
  }
  
  function showFloatingEmoji(emoji) {
    const floating = document.createElement('div');
    floating.className = 'nv-floating-emoji';
    floating.textContent = emoji;
    floating.style.right = `${Math.random() * 200 + 100}px`;
    floating.style.bottom = '200px';
    document.body.appendChild(floating);
    
    setTimeout(() => floating.remove(), 2000);
  }
  
  function updateRank() {
    const allParticipants = [...state.participants, state.currentUser]
      .sort((a, b) => b.points - a.points);
    
    const userIndex = allParticipants.findIndex(p => p.id === state.currentUser.id);
    state.currentUser.rank = userIndex + 1;
  }
  
  function triggerConfetti() {
    const container = document.createElement('div');
    container.className = 'nv-confetti';
    document.body.appendChild(container);
    
    const colors = ['#6366F1', '#22D3EE', '#10B981', '#F59E0B', '#EF4444', '#EC4899'];
    const emojis = ['🎉', '✨', '🌟', '💫', '🎊'];
    
    for (let i = 0; i < 50; i++) {
      const piece = document.createElement('div');
      piece.className = 'nv-confetti-piece';
      piece.textContent = emojis[Math.floor(Math.random() * emojis.length)];
      piece.style.left = `${Math.random() * 100}%`;
      piece.style.fontSize = `${Math.random() * 20 + 10}px`;
      piece.style.animationDelay = `${Math.random() * 2}s`;
      piece.style.animationDuration = `${Math.random() * 2 + 2}s`;
      container.appendChild(piece);
    }
    
    setTimeout(() => container.remove(), 5000);
  }
  
  // ============================================
  // EVENT LISTENERS
  // ============================================
  
  function setupEventListeners() {
    // Tab switching
    document.querySelectorAll('.nv-tab').forEach(tab => {
      tab.addEventListener('click', (e) => {
        state.phase = e.target.dataset.phase;
        renderApp();
        
        // Trigger confetti when going to post
        if (state.phase === 'post') {
          setTimeout(triggerConfetti, 500);
        }
      });
    });
    
    // Go Live button
    const goLiveBtn = document.getElementById('nv-go-live');
    if (goLiveBtn) {
      goLiveBtn.addEventListener('click', () => {
        state.phase = 'live';
        state.currentUser.joinTime = new Date();
        addPoints(MOCK.points.ATTENDANCE, 'Attendance');
        renderApp();
      });
    }
    
    // End Meeting button
    const endMeetingBtn = document.getElementById('nv-end-meeting');
    if (endMeetingBtn) {
      endMeetingBtn.addEventListener('click', () => {
        state.phase = 'post';
        renderApp();
        setTimeout(triggerConfetti, 500);
      });
    }
    
    // Save Goals
    const saveGoalsBtn = document.getElementById('nv-save-goals');
    if (saveGoalsBtn) {
      saveGoalsBtn.addEventListener('click', () => {
        const input = document.getElementById('nv-goals-input');
        if (input && input.value.trim()) {
          state.goals = input.value.trim();
          addPoints(MOCK.points.SET_GOAL, 'Set Goal');
          saveGoalsBtn.textContent = '✅ Saved!';
          saveGoalsBtn.disabled = true;
        }
      });
    }
    
    // Add Prepared Question
    const addQuestionBtn = document.getElementById('nv-add-question');
    if (addQuestionBtn) {
      addQuestionBtn.addEventListener('click', () => {
        const input = document.getElementById('nv-question-input');
        if (input && input.value.trim()) {
          state.preparedQuestions.push({ text: input.value.trim(), asked: false });
          addPoints(MOCK.points.PREPARE_QUESTION, 'Prepare Question');
          input.value = '';
          renderApp();
        }
      });
    }
    
    // Question checkboxes
    document.querySelectorAll('.nv-question-checkbox').forEach(checkbox => {
      checkbox.addEventListener('click', (e) => {
        const index = parseInt(e.target.dataset.index);
        if (!state.preparedQuestions[index].asked) {
          state.preparedQuestions[index].asked = true;
          addPoints(10, 'Question Asked');
          renderApp();
        }
      });
    });
    
    // Poll voting
    document.querySelectorAll('.nv-poll-option').forEach(option => {
      option.addEventListener('click', (e) => {
        const pollId = e.currentTarget.dataset.pollId;
        const optionId = e.currentTarget.dataset.optionId;
        
        if (!state.votedPolls.includes(pollId)) {
          state.votedPolls.push(pollId);
          state.currentUser.selectedOption = optionId;
          
          // Update mock poll data
          const poll = state.polls.find(p => p.id === pollId);
          if (poll) {
            const opt = poll.options.find(o => o.id === optionId);
            if (opt) opt.votes++;
            poll.totalVotes++;
          }
          
          addPoints(MOCK.points.POLL_VOTE, 'Poll Vote');
          renderApp();
        }
      });
    });
    
    // Reactions
    document.querySelectorAll('.nv-reaction-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const emoji = e.target.dataset.emoji;
        if (state.currentUser.reactions.length < 10) {
          state.currentUser.reactions.push({ emoji, time: new Date() });
          showFloatingEmoji(emoji);
          addPoints(MOCK.points.REACTION, 'Reaction');
        }
      });
    });
    
    // Live question
    const askLiveBtn = document.getElementById('nv-ask-live-question');
    if (askLiveBtn) {
      askLiveBtn.addEventListener('click', () => {
        const input = document.getElementById('nv-live-question-input');
        if (input && input.value.trim()) {
          state.currentUser.questionsAsked.push({ text: input.value.trim(), time: new Date() });
          addPoints(MOCK.points.ASK_QUESTION, 'Ask Question');
          input.value = '';
          
          // Show confirmation
          alert('✅ Question submitted anonymously!');
        }
      });
    }
    
    // Rating
    document.querySelectorAll('.nv-rating-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        if (!state.currentUser.rating) {
          state.currentUser.rating = parseInt(e.target.dataset.rating);
          addPoints(MOCK.points.RATE_MEETING, 'Rating');
          renderApp();
        }
      });
    });
    
    // Goal achievement
    document.querySelectorAll('[data-goal]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        if (!state.currentUser.goalAchieved) {
          state.currentUser.goalAchieved = e.target.dataset.goal;
          addPoints(MOCK.points.GOAL_ACHIEVED, 'Goal Check');
          renderApp();
        }
      });
    });
    
    // AI Chat
    const aiSendBtn = document.getElementById('nv-ai-send');
    if (aiSendBtn) {
      aiSendBtn.addEventListener('click', () => {
        const input = document.getElementById('nv-ai-input');
        if (input && input.value.trim()) {
          const question = input.value.trim().toLowerCase();
          
          // Add user message
          state.aiMessages.push({ role: 'user', content: input.value.trim() });
          
          // Find matching response
          let response = MOCK.aiResponses.default;
          for (const [key, value] of Object.entries(MOCK.aiResponses)) {
            if (question.includes(key)) {
              response = value;
              break;
            }
          }
          
          // Add AI response
          state.aiMessages.push({ role: 'assistant', content: response });
          
          addPoints(MOCK.points.AI_QUESTION, 'AI Question');
          input.value = '';
          renderApp();
          
          // Scroll to bottom
          setTimeout(() => {
            const messages = document.getElementById('nv-ai-messages');
            if (messages) messages.scrollTop = messages.scrollHeight;
          }, 100);
        }
      });
    }
    
    // Submit feedback
    const submitFeedbackBtn = document.getElementById('nv-submit-feedback');
    if (submitFeedbackBtn) {
      submitFeedbackBtn.addEventListener('click', () => {
        const input = document.getElementById('nv-feedback-input');
        if (input && input.value.trim()) {
          addPoints(MOCK.points.DETAILED_FEEDBACK, 'Feedback');
          submitFeedbackBtn.textContent = '✅ Thank you!';
          submitFeedbackBtn.disabled = true;
          input.disabled = true;
        }
      });
    }
    
    // Share on Slack (mock)
    const shareSlackBtn = document.getElementById('nv-share-slack');
    if (shareSlackBtn) {
      shareSlackBtn.addEventListener('click', () => {
        alert('📤 Shared to #general on Slack!\n\n"I just earned ' + state.currentUser.points + ' pts and finished #' + state.currentUser.rank + ' at Tech Night! 🎮"');
      });
    }
  }
  
  // Start the app
  init();
  
})();

