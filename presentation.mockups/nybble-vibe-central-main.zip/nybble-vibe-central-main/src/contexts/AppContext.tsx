import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { Event, Participant, Poll, GlobalStats, PointsConfig, defaultPointsConfig, EventPhase } from '@/data/mockData';

interface AppState {
  events: Event[];
  participants: Participant[];
  polls: Poll[];
  globalStats: GlobalStats | null;
  pointsConfig: PointsConfig;
  isLoading: boolean;
  openAIKey: string;
}

interface AppContextType extends AppState {
  setEvents: (events: Event[]) => void;
  setParticipants: (participants: Participant[]) => void;
  setPolls: (polls: Poll[]) => void;
  setGlobalStats: (stats: GlobalStats) => void;
  setPointsConfig: (config: PointsConfig) => void;
  setIsLoading: (loading: boolean) => void;
  setOpenAIKey: (key: string) => void;
  updateEventPhase: (eventId: string, phase: EventPhase) => void;
  updatePollStatus: (pollId: string, status: Poll['status']) => void;
  addEvent: (event: Event) => void;
  addPoll: (poll: Poll) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [events, setEvents] = useState<Event[]>([]);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [polls, setPolls] = useState<Poll[]>([]);
  const [globalStats, setGlobalStats] = useState<GlobalStats | null>(null);
  const [pointsConfig, setPointsConfig] = useState<PointsConfig>(defaultPointsConfig);
  const [isLoading, setIsLoading] = useState(false);
  const [openAIKey, setOpenAIKey] = useState('');

  const updateEventPhase = useCallback((eventId: string, phase: EventPhase) => {
    setEvents(prev => prev.map(e => e.id === eventId ? { ...e, phase } : e));
  }, []);

  const updatePollStatus = useCallback((pollId: string, status: Poll['status']) => {
    setPolls(prev => prev.map(p => p.id === pollId ? { ...p, status } : p));
  }, []);

  const addEvent = useCallback((event: Event) => {
    setEvents(prev => [...prev, event]);
  }, []);

  const addPoll = useCallback((poll: Poll) => {
    setPolls(prev => [...prev, poll]);
  }, []);

  const value: AppContextType = {
    events,
    participants,
    polls,
    globalStats,
    pointsConfig,
    isLoading,
    openAIKey,
    setEvents,
    setParticipants,
    setPolls,
    setGlobalStats,
    setPointsConfig,
    setIsLoading,
    setOpenAIKey,
    updateEventPhase,
    updatePollStatus,
    addEvent,
    addPoll,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
