export type EventPhase = 'pre' | 'live' | 'post' | 'closed';

export interface Event {
  id: string;
  title: string;
  description: string;
  startTime: string;
  endTime: string;
  phase: EventPhase;
  participantCount: number;
  allowAnonymousQuestions: boolean;
  showLeaderboard: boolean;
  requirePreparation: boolean;
  enableAIQuestions: boolean;
  hasTranscript: boolean;
}

export interface Participant {
  id: string;
  name: string;
  email: string;
  avatar: string;
  points: number;
  rank: number;
  attendancePercent: number;
  badges: string[];
  eventsAttended: number;
  pollsVoted: number;
  questionsAsked: number;
}

export interface Poll {
  id: string;
  eventId: string;
  question: string;
  options: PollOption[];
  status: 'draft' | 'active' | 'closed';
  showResultsTo: 'all' | 'voted' | 'admin';
  totalVotes: number;
  createdAt: string;
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
}

export interface AgendaItem {
  id: string;
  title: string;
  duration: string;
}

export interface Question {
  id: string;
  text: string;
  isAnonymous: boolean;
  upvotes: number;
  answered: boolean;
}

export interface GlobalStats {
  averageRating: number;
  attendanceRate: number;
  pollParticipation: number;
  feedbackCompletion: number;
  totalEvents: number;
  totalParticipants: number;
  totalPoints: number;
}

export interface EngagementTrend {
  month: string;
  engagement: number;
  attendance: number;
  participation: number;
}

export interface PointsConfig {
  attendance: number;
  reaction: number;
  pollVote: number;
  question: number;
  feedback: number;
  goalSet: number;
  prepQuestion: number;
}

// Mock Events
export const mockEvents: Event[] = [
  {
    id: '1',
    title: 'Q4 Planning Sprint Review',
    description: 'Review of Q4 planning milestones and upcoming sprint goals',
    startTime: '2024-12-05T14:00:00Z',
    endTime: '2024-12-05T15:30:00Z',
    phase: 'live',
    participantCount: 24,
    allowAnonymousQuestions: true,
    showLeaderboard: true,
    requirePreparation: true,
    enableAIQuestions: true,
    hasTranscript: false,
  },
  {
    id: '2',
    title: 'Product Roadmap 2025',
    description: 'Annual product roadmap presentation and feedback session',
    startTime: '2024-12-10T10:00:00Z',
    endTime: '2024-12-10T12:00:00Z',
    phase: 'pre',
    participantCount: 45,
    allowAnonymousQuestions: true,
    showLeaderboard: true,
    requirePreparation: false,
    enableAIQuestions: true,
    hasTranscript: false,
  },
  {
    id: '3',
    title: 'Engineering All-Hands',
    description: 'Monthly engineering team sync and updates',
    startTime: '2024-11-28T15:00:00Z',
    endTime: '2024-11-28T16:00:00Z',
    phase: 'post',
    participantCount: 67,
    allowAnonymousQuestions: true,
    showLeaderboard: true,
    requirePreparation: false,
    enableAIQuestions: true,
    hasTranscript: true,
  },
  {
    id: '4',
    title: 'Design System Workshop',
    description: 'Hands-on workshop for the new design system components',
    startTime: '2024-11-20T09:00:00Z',
    endTime: '2024-11-20T11:00:00Z',
    phase: 'closed',
    participantCount: 18,
    allowAnonymousQuestions: false,
    showLeaderboard: true,
    requirePreparation: true,
    enableAIQuestions: false,
    hasTranscript: true,
  },
  {
    id: '5',
    title: 'Customer Success Stories',
    description: 'Sharing recent customer wins and lessons learned',
    startTime: '2024-12-15T13:00:00Z',
    endTime: '2024-12-15T14:00:00Z',
    phase: 'pre',
    participantCount: 32,
    allowAnonymousQuestions: true,
    showLeaderboard: false,
    requirePreparation: false,
    enableAIQuestions: true,
    hasTranscript: false,
  },
];

// Mock Participants
export const mockParticipants: Participant[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    email: 'sarah.chen@company.com',
    avatar: 'SC',
    points: 2450,
    rank: 1,
    attendancePercent: 98,
    badges: ['🏆', '🔥', '💡', '🎯'],
    eventsAttended: 24,
    pollsVoted: 45,
    questionsAsked: 12,
  },
  {
    id: '2',
    name: 'Marcus Johnson',
    email: 'marcus.j@company.com',
    avatar: 'MJ',
    points: 2180,
    rank: 2,
    attendancePercent: 95,
    badges: ['🏆', '👏', '🚀'],
    eventsAttended: 22,
    pollsVoted: 38,
    questionsAsked: 8,
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    email: 'emily.r@company.com',
    avatar: 'ER',
    points: 1920,
    rank: 3,
    attendancePercent: 92,
    badges: ['💡', '🎯', '❤️'],
    eventsAttended: 20,
    pollsVoted: 42,
    questionsAsked: 15,
  },
  {
    id: '4',
    name: 'David Kim',
    email: 'david.kim@company.com',
    avatar: 'DK',
    points: 1750,
    rank: 4,
    attendancePercent: 88,
    badges: ['🔥', '👏'],
    eventsAttended: 18,
    pollsVoted: 35,
    questionsAsked: 6,
  },
  {
    id: '5',
    name: 'Lisa Wang',
    email: 'lisa.wang@company.com',
    avatar: 'LW',
    points: 1680,
    rank: 5,
    attendancePercent: 90,
    badges: ['💡', '🚀'],
    eventsAttended: 19,
    pollsVoted: 40,
    questionsAsked: 10,
  },
  {
    id: '6',
    name: 'James Wilson',
    email: 'james.w@company.com',
    avatar: 'JW',
    points: 1520,
    rank: 6,
    attendancePercent: 85,
    badges: ['🎯'],
    eventsAttended: 16,
    pollsVoted: 30,
    questionsAsked: 4,
  },
  {
    id: '7',
    name: 'Anna Schmidt',
    email: 'anna.s@company.com',
    avatar: 'AS',
    points: 1450,
    rank: 7,
    attendancePercent: 82,
    badges: ['👏', '❤️'],
    eventsAttended: 15,
    pollsVoted: 28,
    questionsAsked: 7,
  },
  {
    id: '8',
    name: 'Michael Brown',
    email: 'michael.b@company.com',
    avatar: 'MB',
    points: 1380,
    rank: 8,
    attendancePercent: 80,
    badges: ['🔥'],
    eventsAttended: 14,
    pollsVoted: 25,
    questionsAsked: 3,
  },
  {
    id: '9',
    name: 'Sophie Taylor',
    email: 'sophie.t@company.com',
    avatar: 'ST',
    points: 1290,
    rank: 9,
    attendancePercent: 78,
    badges: ['💡'],
    eventsAttended: 13,
    pollsVoted: 22,
    questionsAsked: 5,
  },
  {
    id: '10',
    name: 'Chris Martinez',
    email: 'chris.m@company.com',
    avatar: 'CM',
    points: 1150,
    rank: 10,
    attendancePercent: 75,
    badges: ['🚀'],
    eventsAttended: 12,
    pollsVoted: 20,
    questionsAsked: 2,
  },
];

// Mock Polls
export const mockPolls: Poll[] = [
  {
    id: '1',
    eventId: '1',
    question: 'What should be our top priority for Q1 2025?',
    options: [
      { id: '1a', text: 'Feature Development', votes: 12 },
      { id: '1b', text: 'Technical Debt', votes: 8 },
      { id: '1c', text: 'Customer Feedback', votes: 15 },
      { id: '1d', text: 'Team Growth', votes: 5 },
    ],
    status: 'active',
    showResultsTo: 'all',
    totalVotes: 40,
    createdAt: '2024-12-05T14:15:00Z',
  },
  {
    id: '2',
    eventId: '1',
    question: 'Preferred meeting frequency?',
    options: [
      { id: '2a', text: 'Weekly', votes: 18 },
      { id: '2b', text: 'Bi-weekly', votes: 14 },
      { id: '2c', text: 'Monthly', votes: 6 },
    ],
    status: 'closed',
    showResultsTo: 'all',
    totalVotes: 38,
    createdAt: '2024-12-05T14:30:00Z',
  },
  {
    id: '3',
    eventId: '2',
    question: 'Which feature excites you most?',
    options: [
      { id: '3a', text: 'AI Integration', votes: 0 },
      { id: '3b', text: 'Mobile App', votes: 0 },
      { id: '3c', text: 'Analytics Dashboard', votes: 0 },
      { id: '3d', text: 'Team Collaboration', votes: 0 },
    ],
    status: 'draft',
    showResultsTo: 'voted',
    totalVotes: 0,
    createdAt: '2024-12-04T10:00:00Z',
  },
  {
    id: '4',
    eventId: '3',
    question: 'Rate the engineering update quality',
    options: [
      { id: '4a', text: 'Excellent', votes: 32 },
      { id: '4b', text: 'Good', votes: 25 },
      { id: '4c', text: 'Average', votes: 8 },
      { id: '4d', text: 'Needs Improvement', votes: 2 },
    ],
    status: 'closed',
    showResultsTo: 'all',
    totalVotes: 67,
    createdAt: '2024-11-28T15:30:00Z',
  },
];

// Mock Global Stats
export const mockGlobalStats: GlobalStats = {
  averageRating: 4.6,
  attendanceRate: 87,
  pollParticipation: 78,
  feedbackCompletion: 65,
  totalEvents: 48,
  totalParticipants: 156,
  totalPoints: 45680,
};

// Mock Engagement Trends
export const mockEngagementTrends: EngagementTrend[] = [
  { month: 'Sep', engagement: 72, attendance: 85, participation: 68 },
  { month: 'Oct', engagement: 78, attendance: 88, participation: 72 },
  { month: 'Nov', engagement: 85, attendance: 90, participation: 78 },
  { month: 'Dec', engagement: 82, attendance: 87, participation: 75 },
];

// Mock Agenda Items
export const mockAgendaItems: AgendaItem[] = [
  { id: '1', title: 'Welcome & Introduction', duration: '5 min' },
  { id: '2', title: 'Q4 Progress Review', duration: '20 min' },
  { id: '3', title: 'Sprint Goals Discussion', duration: '30 min' },
  { id: '4', title: 'Q&A Session', duration: '15 min' },
  { id: '5', title: 'Wrap-up & Next Steps', duration: '10 min' },
];

// Mock Questions
export const mockQuestions: Question[] = [
  { id: '1', text: 'When will the new API be ready?', isAnonymous: false, upvotes: 8, answered: false },
  { id: '2', text: 'Can we get more details on the timeline?', isAnonymous: true, upvotes: 5, answered: true },
  { id: '3', text: 'What about the mobile team resources?', isAnonymous: false, upvotes: 3, answered: false },
];

// Default Points Config
export const defaultPointsConfig: PointsConfig = {
  attendance: 50,
  reaction: 5,
  pollVote: 15,
  question: 25,
  feedback: 40,
  goalSet: 20,
  prepQuestion: 15,
};

// Current User Mock (for extension)
export const mockCurrentUser: Participant = {
  id: 'current',
  name: 'You',
  email: 'you@company.com',
  avatar: 'YO',
  points: 1580,
  rank: 6,
  attendancePercent: 92,
  badges: ['🔥', '💡', '👏'],
  eventsAttended: 18,
  pollsVoted: 32,
  questionsAsked: 9,
};
