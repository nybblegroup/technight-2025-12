import { Button } from '@/components/ui/button';
import { mockCurrentUser, mockParticipants } from '@/data/mockData';
import { ExternalLink, Trophy, Medal, Award } from 'lucide-react';

export const ClosedView: React.FC = () => {
  const topThree = mockParticipants.slice(0, 3);

  return (
    <div className="p-4 space-y-4">
      {/* Event Closed */}
      <div className="text-center p-6 rounded-lg bg-gradient-to-b from-primary/10 to-transparent border border-primary/20">
        <div className="text-4xl mb-3">🏁</div>
        <h2 className="font-display font-bold text-xl text-foreground mb-1">
          Event Closed
        </h2>
        <p className="text-sm text-muted-foreground">
          Thank you for participating!
        </p>
      </div>

      {/* Final Stats */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-4 text-center">
          🎯 Your Final Results
        </h3>
        <div className="flex items-center justify-center gap-6 mb-4">
          <div className="text-center">
            <p className="text-3xl font-bold text-primary font-display">
              {mockCurrentUser.points}
            </p>
            <p className="text-xs text-muted-foreground">Total Points</p>
          </div>
          <div className="w-px h-12 bg-border" />
          <div className="text-center">
            <p className="text-3xl font-bold text-foreground font-display">
              #{mockCurrentUser.rank}
            </p>
            <p className="text-xs text-muted-foreground">Final Rank</p>
          </div>
        </div>

        <div className="flex justify-center gap-2">
          {mockCurrentUser.badges.map((badge, i) => (
            <span
              key={i}
              className="text-xl p-2 rounded-lg bg-primary/10"
            >
              {badge}
            </span>
          ))}
        </div>
      </div>

      {/* Mini Leaderboard */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-3">
          🏆 Top Performers
        </h3>
        <div className="space-y-2">
          {topThree.map((participant, index) => {
            const icons = [Trophy, Medal, Award];
            const colors = ['text-yellow-400', 'text-gray-300', 'text-amber-500'];
            const Icon = icons[index];

            return (
              <div
                key={participant.id}
                className="flex items-center gap-3 p-2 rounded-lg bg-muted"
              >
                <Icon className={`w-5 h-5 ${colors[index]}`} />
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/20 text-primary text-xs font-semibold">
                  {participant.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {participant.name}
                  </p>
                </div>
                <p className="text-sm font-bold text-primary">
                  {participant.points}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* CTA */}
      <div className="space-y-2">
        <Button className="w-full" variant="outline">
          <ExternalLink className="w-4 h-4 mr-2" />
          View Full Results in Dashboard
        </Button>
        <p className="text-xs text-muted-foreground text-center">
          Access detailed analytics and event history
        </p>
      </div>

      {/* Fun Message */}
      <div className="text-center p-4 rounded-lg bg-gradient-to-r from-primary/5 to-secondary/5 border border-primary/10">
        <p className="text-sm text-foreground">
          🎮 Great engagement! See you at the next event!
        </p>
      </div>
    </div>
  );
};
