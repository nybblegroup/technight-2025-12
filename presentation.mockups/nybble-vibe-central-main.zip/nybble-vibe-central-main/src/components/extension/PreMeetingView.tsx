import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Users } from 'lucide-react';
import { mockAgendaItems } from '@/data/mockData';

interface PreMeetingViewProps {
  onPointsEarned: (points: number, action: string) => void;
}

export const PreMeetingView: React.FC<PreMeetingViewProps> = ({ onPointsEarned }) => {
  const [goal, setGoal] = useState('');
  const [goalSaved, setGoalSaved] = useState(false);
  const [newQuestion, setNewQuestion] = useState('');
  const [prepQuestions, setPrepQuestions] = useState<{ text: string; checked: boolean }[]>([]);

  const handleSaveGoal = () => {
    if (goal.trim() && !goalSaved) {
      setGoalSaved(true);
      onPointsEarned(20, 'Set Goal');
    }
  };

  const handleAddQuestion = () => {
    if (newQuestion.trim()) {
      setPrepQuestions([...prepQuestions, { text: newQuestion, checked: false }]);
      setNewQuestion('');
      onPointsEarned(15, 'Prep Question');
    }
  };

  const toggleQuestion = (index: number) => {
    setPrepQuestions(
      prepQuestions.map((q, i) =>
        i === index ? { ...q, checked: !q.checked } : q
      )
    );
  };

  return (
    <div className="p-4 space-y-4">
      {/* Attendees */}
      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary/10 text-secondary text-sm">
        <Users className="w-4 h-4" />
        <span>12 attendees joined</span>
      </div>

      {/* Agenda Preview */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-3 flex items-center gap-2">
          📋 Agenda Preview
        </h3>
        <ul className="space-y-2">
          {mockAgendaItems.map((item) => (
            <li
              key={item.id}
              className="flex items-center justify-between text-sm"
            >
              <span className="text-foreground">{item.title}</span>
              <span className="text-xs text-muted-foreground">{item.duration}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Set Your Goal */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-3 flex items-center gap-2">
          🎯 Set Your Goal
          <span className="text-xs text-success font-normal">+20 pts</span>
        </h3>
        {goalSaved ? (
          <div className="p-3 rounded-lg bg-success/10 border border-success/20">
            <p className="text-sm text-foreground">{goal}</p>
            <p className="text-xs text-success mt-1">✓ Goal saved!</p>
          </div>
        ) : (
          <div className="space-y-2">
            <Input
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              placeholder="What do you want to achieve?"
              className="bg-muted border-border text-sm"
            />
            <Button
              onClick={handleSaveGoal}
              size="sm"
              className="w-full"
              disabled={!goal.trim()}
            >
              Save Goal
            </Button>
          </div>
        )}
      </div>

      {/* Prepare Questions */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-3 flex items-center gap-2">
          ❓ Prepare Questions
          <span className="text-xs text-success font-normal">+15 pts each</span>
        </h3>

        {prepQuestions.length > 0 && (
          <ul className="space-y-2 mb-3">
            <AnimatePresence>
              {prepQuestions.map((q, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-start gap-2"
                >
                  <Checkbox
                    checked={q.checked}
                    onCheckedChange={() => toggleQuestion(index)}
                    className="mt-0.5"
                  />
                  <span
                    className={`text-sm ${
                      q.checked
                        ? 'text-muted-foreground line-through'
                        : 'text-foreground'
                    }`}
                  >
                    {q.text}
                  </span>
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        )}

        <div className="flex gap-2">
          <Input
            value={newQuestion}
            onChange={(e) => setNewQuestion(e.target.value)}
            placeholder="Add a question..."
            className="bg-muted border-border text-sm"
            onKeyDown={(e) => e.key === 'Enter' && handleAddQuestion()}
          />
          <Button
            onClick={handleAddQuestion}
            size="icon"
            variant="outline"
            disabled={!newQuestion.trim()}
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};
