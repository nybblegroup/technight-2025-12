import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { EmojiReaction } from '@/components/ui/EmojiReaction';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { motion } from 'framer-motion';
import { Send } from 'lucide-react';
import { mockPolls } from '@/data/mockData';

interface LiveMeetingViewProps {
  onPointsEarned: (points: number, action: string) => void;
}

const REACTION_EMOJIS = ['🔥', '👏', '💡', '🤔', '❤️', '🚀'];
const MAX_REACTIONS = 10;

export const LiveMeetingView: React.FC<LiveMeetingViewProps> = ({ onPointsEarned }) => {
  const [reactionsUsed, setReactionsUsed] = useState(0);
  const [selectedOption, setSelectedOption] = useState('');
  const [hasVoted, setHasVoted] = useState(false);
  const [question, setQuestion] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [submittedQuestions, setSubmittedQuestions] = useState<string[]>([]);

  const activePoll = mockPolls.find(p => p.status === 'active');

  const handleReaction = (emoji: string) => {
    if (reactionsUsed < MAX_REACTIONS) {
      setReactionsUsed(prev => prev + 1);
      onPointsEarned(5, 'Reaction');
    }
  };

  const handleVote = () => {
    if (selectedOption && !hasVoted) {
      setHasVoted(true);
      onPointsEarned(15, 'Poll Vote');
    }
  };

  const handleSubmitQuestion = () => {
    if (question.trim()) {
      setSubmittedQuestions([...submittedQuestions, question]);
      setQuestion('');
      onPointsEarned(25, 'Question');
    }
  };

  return (
    <div className="p-4 space-y-4">
      {/* Active Poll */}
      {activePoll && (
        <div className="bg-card rounded-lg border border-primary/30 p-4">
          <div className="flex items-center gap-2 mb-3">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-live opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-live" />
            </span>
            <h3 className="font-display font-semibold text-sm text-foreground">
              Active Poll
            </h3>
            <span className="text-xs text-success ml-auto">+15 pts</span>
          </div>

          <p className="text-sm text-foreground mb-3">{activePoll.question}</p>

          {hasVoted ? (
            <div className="p-3 rounded-lg bg-success/10 border border-success/20">
              <p className="text-sm text-success">✓ Vote submitted!</p>
            </div>
          ) : (
            <>
              <RadioGroup
                value={selectedOption}
                onValueChange={setSelectedOption}
                className="space-y-2 mb-3"
              >
                {activePoll.options.map((option) => (
                  <div key={option.id} className="flex items-center space-x-2">
                    <RadioGroupItem value={option.id} id={option.id} />
                    <Label htmlFor={option.id} className="text-sm text-foreground cursor-pointer">
                      {option.text}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
              <Button
                onClick={handleVote}
                size="sm"
                className="w-full"
                disabled={!selectedOption}
              >
                Vote
              </Button>
            </>
          )}
        </div>
      )}

      {/* Quick Reactions */}
      <div className="bg-card rounded-lg border border-border p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-display font-semibold text-sm text-foreground flex items-center gap-2">
            ⚡ Quick Reactions
            <span className="text-xs text-success font-normal">+5 pts</span>
          </h3>
          <span className="text-xs text-muted-foreground">
            {reactionsUsed}/{MAX_REACTIONS} used
          </span>
        </div>

        <div className="grid grid-cols-6 gap-1">
          {REACTION_EMOJIS.map((emoji) => (
            <EmojiReaction
              key={emoji}
              emoji={emoji}
              onClick={() => handleReaction(emoji)}
              disabled={reactionsUsed >= MAX_REACTIONS}
            />
          ))}
        </div>

        {reactionsUsed >= MAX_REACTIONS && (
          <p className="text-xs text-muted-foreground text-center mt-2">
            Reaction limit reached
          </p>
        )}
      </div>

      {/* Ask a Question */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-3 flex items-center gap-2">
          ❓ Ask a Question
          <span className="text-xs text-success font-normal">+25 pts</span>
        </h3>

        {submittedQuestions.length > 0 && (
          <div className="space-y-2 mb-3">
            {submittedQuestions.map((q, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-2 rounded bg-muted text-sm text-foreground"
              >
                {q}
                <span className="text-xs text-success ml-2">✓ Submitted</span>
              </motion.div>
            ))}
          </div>
        )}

        <div className="space-y-3">
          <Input
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Type your question..."
            className="bg-muted border-border text-sm"
            onKeyDown={(e) => e.key === 'Enter' && handleSubmitQuestion()}
          />

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Checkbox
                id="anonymous"
                checked={isAnonymous}
                onCheckedChange={(checked) => setIsAnonymous(checked as boolean)}
              />
              <Label htmlFor="anonymous" className="text-xs text-muted-foreground cursor-pointer">
                Anonymous
              </Label>
            </div>

            <Button
              onClick={handleSubmitQuestion}
              size="sm"
              disabled={!question.trim()}
            >
              <Send className="w-3 h-3 mr-1" />
              Submit
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
