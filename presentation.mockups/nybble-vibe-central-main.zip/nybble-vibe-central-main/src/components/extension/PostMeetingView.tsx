import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, CheckCircle2 } from 'lucide-react';
import { mockCurrentUser } from '@/data/mockData';

interface PostMeetingViewProps {
  onPointsEarned: (points: number, action: string) => void;
}

const RATING_EMOJIS = ['😞', '😐', '🙂', '😊', '🤩'];

export const PostMeetingView: React.FC<PostMeetingViewProps> = ({ onPointsEarned }) => {
  const [rating, setRating] = useState<number | null>(null);
  const [goalAchieved, setGoalAchieved] = useState('');
  const [feedback, setFeedback] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiMessages, setAiMessages] = useState<{ role: 'user' | 'ai'; text: string }[]>([]);
  const [isAiThinking, setIsAiThinking] = useState(false);

  const handleSubmitFeedback = () => {
    if (rating !== null && goalAchieved) {
      setFeedbackSubmitted(true);
      onPointsEarned(40, 'Feedback');
    }
  };

  const handleAskAI = async () => {
    if (!aiQuestion.trim()) return;

    setAiMessages([...aiMessages, { role: 'user', text: aiQuestion }]);
    setAiQuestion('');
    setIsAiThinking(true);

    // Simulate AI response
    await new Promise(resolve => setTimeout(resolve, 1500));

    const responses = [
      "Based on the meeting transcript, the main discussion points were around Q4 priorities and team alignment.",
      "The team agreed on focusing on customer feedback for the next sprint cycle.",
      "Key action items include updating the roadmap and scheduling follow-ups.",
    ];

    setAiMessages(prev => [
      ...prev,
      { role: 'ai', text: responses[Math.floor(Math.random() * responses.length)] },
    ]);
    setIsAiThinking(false);
  };

  return (
    <div className="p-4 space-y-4">
      {/* Completion Badge */}
      <div className="flex items-center gap-3 p-4 rounded-lg bg-success/10 border border-success/20">
        <CheckCircle2 className="w-8 h-8 text-success" />
        <div>
          <p className="font-display font-semibold text-foreground">Meeting Completed! ✅</p>
          <p className="text-sm text-muted-foreground">Great participation today</p>
        </div>
      </div>

      {/* Your Stats */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-3">
          📊 Your Stats
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="text-center p-2 rounded-lg bg-muted">
            <p className="text-lg font-bold text-primary">{mockCurrentUser.points}</p>
            <p className="text-xs text-muted-foreground">Total Points</p>
          </div>
          <div className="text-center p-2 rounded-lg bg-muted">
            <p className="text-lg font-bold text-foreground">#{mockCurrentUser.rank}</p>
            <p className="text-xs text-muted-foreground">Rank</p>
          </div>
          <div className="text-center p-2 rounded-lg bg-muted">
            <p className="text-lg font-bold text-foreground">{mockCurrentUser.attendancePercent}%</p>
            <p className="text-xs text-muted-foreground">Attendance</p>
          </div>
          <div className="text-center p-2 rounded-lg bg-muted">
            <p className="text-lg font-bold text-foreground">{mockCurrentUser.pollsVoted}</p>
            <p className="text-xs text-muted-foreground">Polls Voted</p>
          </div>
        </div>
      </div>

      {/* Badges Earned */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-3">
          🏆 Badges Earned
        </h3>
        <div className="flex gap-2">
          {mockCurrentUser.badges.map((badge, i) => (
            <span
              key={i}
              className="text-2xl p-2 rounded-lg bg-muted hover:bg-primary/10 transition-colors cursor-pointer"
              title="Badge earned!"
            >
              {badge}
            </span>
          ))}
        </div>
      </div>

      {/* Feedback Form */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-3 flex items-center gap-2">
          💬 Rate this Meeting
          <span className="text-xs text-success font-normal">+40 pts</span>
        </h3>

        {feedbackSubmitted ? (
          <div className="p-3 rounded-lg bg-success/10 border border-success/20 text-center">
            <p className="text-sm text-success">✓ Feedback submitted! Thank you!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Rating */}
            <div className="flex justify-center gap-2">
              {RATING_EMOJIS.map((emoji, i) => (
                <button
                  key={i}
                  onClick={() => setRating(i + 1)}
                  className={`text-2xl p-2 rounded-lg transition-all ${
                    rating === i + 1
                      ? 'bg-primary/20 scale-110'
                      : 'bg-muted hover:bg-primary/10'
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>

            {/* Goal Achievement */}
            <div>
              <p className="text-sm text-foreground mb-2">Did you achieve your goal?</p>
              <RadioGroup value={goalAchieved} onValueChange={setGoalAchieved}>
                <div className="flex gap-4">
                  {[
                    { value: 'yes', label: 'Yes' },
                    { value: 'partially', label: 'Partially' },
                    { value: 'no', label: 'No' },
                  ].map((option) => (
                    <div key={option.value} className="flex items-center gap-1.5">
                      <RadioGroupItem value={option.value} id={option.value} />
                      <Label htmlFor={option.value} className="text-sm cursor-pointer">
                        {option.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>

            {/* Comments */}
            <Textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Any additional comments? (optional)"
              className="bg-muted border-border text-sm resize-none"
              rows={2}
            />

            <Button
              onClick={handleSubmitFeedback}
              className="w-full"
              disabled={rating === null || !goalAchieved}
            >
              Submit Feedback
            </Button>
          </div>
        )}
      </div>

      {/* AI Q&A */}
      <div className="bg-card rounded-lg border border-border p-4">
        <h3 className="font-display font-semibold text-sm text-foreground mb-3">
          🤖 Ask AI about the Meeting
        </h3>

        {aiMessages.length > 0 && (
          <div className="space-y-2 mb-3 max-h-40 overflow-y-auto scrollbar-thin">
            <AnimatePresence>
              {aiMessages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-2 rounded-lg text-sm ${
                    msg.role === 'user'
                      ? 'bg-primary/10 text-foreground ml-4'
                      : 'bg-muted text-foreground mr-4'
                  }`}
                >
                  {msg.text}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {isAiThinking && (
          <div className="flex items-center gap-2 p-2 text-sm text-muted-foreground mb-3">
            <span className="animate-pulse">🤖 Thinking...</span>
          </div>
        )}

        <div className="flex gap-2">
          <Input
            value={aiQuestion}
            onChange={(e) => setAiQuestion(e.target.value)}
            placeholder="Ask about the meeting..."
            className="bg-muted border-border text-sm"
            onKeyDown={(e) => e.key === 'Enter' && handleAskAI()}
          />
          <Button size="icon" onClick={handleAskAI} disabled={!aiQuestion.trim() || isAiThinking}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};
