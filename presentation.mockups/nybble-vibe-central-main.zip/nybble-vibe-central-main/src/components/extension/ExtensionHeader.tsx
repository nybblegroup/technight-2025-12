import { EventPhase } from '@/data/mockData';
import { PhaseChip } from '@/components/ui/PhaseChip';
import { Wifi, WifiOff } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ExtensionHeaderProps {
  eventTitle: string;
  phase: EventPhase;
  points: number;
  rank: number;
  isOnline?: boolean;
}

export const ExtensionHeader: React.FC<ExtensionHeaderProps> = ({
  eventTitle,
  phase,
  points,
  rank,
  isOnline = true,
}) => {
  return (
    <header className="sticky top-0 z-10 bg-card/95 backdrop-blur-sm border-b border-border p-4">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <h1 className="font-display font-semibold text-sm text-foreground truncate">
            {eventTitle}
          </h1>
        </div>
        <PhaseChip phase={phase} size="sm" />
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="text-center">
            <p className="text-xl font-bold text-primary font-display">{points.toLocaleString()}</p>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Points</p>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="text-center">
            <p className="text-xl font-bold text-foreground font-display">#{rank}</p>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Rank</p>
          </div>
        </div>

        <div className={cn(
          'flex items-center gap-1.5 px-2 py-1 rounded-full text-xs',
          isOnline 
            ? 'bg-success/20 text-success'
            : 'bg-destructive/20 text-destructive'
        )}>
          {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
          {isOnline ? 'Online' : 'Offline'}
        </div>
      </div>
    </header>
  );
};
