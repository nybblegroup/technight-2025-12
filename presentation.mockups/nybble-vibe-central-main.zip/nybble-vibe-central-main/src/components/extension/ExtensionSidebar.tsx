import { useState, useCallback } from 'react';
import { ExtensionHeader } from './ExtensionHeader';
import { PreMeetingView } from './PreMeetingView';
import { LiveMeetingView } from './LiveMeetingView';
import { PostMeetingView } from './PostMeetingView';
import { ClosedView } from './ClosedView';
import { EventPhase, mockCurrentUser, mockEvents } from '@/data/mockData';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ExtensionSidebarProps {
  initialPhase?: EventPhase;
}

export const ExtensionSidebar: React.FC<ExtensionSidebarProps> = ({
  initialPhase = 'pre',
}) => {
  const [phase, setPhase] = useState<EventPhase>(initialPhase);
  const [points, setPoints] = useState(mockCurrentUser.points);
  const [rank] = useState(mockCurrentUser.rank);
  const [pointsAnimations, setPointsAnimations] = useState<{ id: string; points: number; action: string }[]>([]);

  const event = mockEvents.find(e => e.phase === 'live') || mockEvents[0];

  const handlePointsEarned = useCallback((earnedPoints: number, action: string) => {
    setPoints(prev => prev + earnedPoints);
    
    const id = Math.random().toString(36).substr(2, 9);
    setPointsAnimations(prev => [...prev, { id, points: earnedPoints, action }]);
    
    setTimeout(() => {
      setPointsAnimations(prev => prev.filter(a => a.id !== id));
    }, 1500);
  }, []);

  const renderPhaseContent = () => {
    switch (phase) {
      case 'pre':
        return <PreMeetingView onPointsEarned={handlePointsEarned} />;
      case 'live':
        return <LiveMeetingView onPointsEarned={handlePointsEarned} />;
      case 'post':
        return <PostMeetingView onPointsEarned={handlePointsEarned} />;
      case 'closed':
        return <ClosedView />;
    }
  };

  return (
    <div className="w-[300px] h-full bg-background border-l border-border flex flex-col relative">
      {/* Points Animations */}
      <AnimatePresence>
        {pointsAnimations.map((anim) => (
          <motion.div
            key={anim.id}
            initial={{ opacity: 1, y: 60, x: -10 }}
            animate={{ opacity: 0, y: 0, x: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, ease: 'easeOut' }}
            className="absolute top-14 right-4 z-50 pointer-events-none"
          >
            <div className="bg-success/90 text-success-foreground px-3 py-1.5 rounded-full text-sm font-bold shadow-lg">
              +{anim.points} pts
              <span className="text-xs font-normal ml-1 opacity-80">{anim.action}</span>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      <ExtensionHeader
        eventTitle={event.title}
        phase={phase}
        points={points}
        rank={rank}
      />

      {/* Phase Selector (for demo) */}
      <div className="px-4 py-2 border-b border-border bg-card/50">
        <p className="text-xs text-muted-foreground mb-2">Demo: Switch phase</p>
        <div className="flex gap-1">
          {(['pre', 'live', 'post', 'closed'] as EventPhase[]).map((p) => (
            <button
              key={p}
              onClick={() => setPhase(p)}
              className={cn(
                'flex-1 px-2 py-1 text-xs rounded font-medium transition-colors',
                phase === p
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              )}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        <AnimatePresence mode="wait">
          <motion.div
            key={phase}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {renderPhaseContent()}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};
