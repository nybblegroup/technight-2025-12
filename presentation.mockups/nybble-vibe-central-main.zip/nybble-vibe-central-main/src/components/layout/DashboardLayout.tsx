import { ReactNode } from 'react';
import { Sidebar } from './Sidebar';
import { cn } from '@/lib/utils';

interface DashboardLayoutProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  actions?: ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  children,
  title,
  subtitle,
  actions,
}) => {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="pl-64">
        <div className="min-h-screen">
          {(title || actions) && (
            <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-lg border-b border-border">
              <div className="flex items-center justify-between px-8 py-6">
                <div>
                  {title && (
                    <h1 className="font-display font-bold text-2xl text-foreground">
                      {title}
                    </h1>
                  )}
                  {subtitle && (
                    <p className="text-muted-foreground mt-1">{subtitle}</p>
                  )}
                </div>
                {actions && <div className="flex items-center gap-3">{actions}</div>}
              </div>
            </header>
          )}
          <div className="p-8">{children}</div>
        </div>
      </main>
    </div>
  );
};
