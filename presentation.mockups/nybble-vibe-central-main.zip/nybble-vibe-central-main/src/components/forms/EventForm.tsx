import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Event, EventPhase } from '@/data/mockData';

interface EventFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (event: Omit<Event, 'id' | 'participantCount' | 'hasTranscript'>) => void;
}

export const EventForm: React.FC<EventFormProps> = ({
  open,
  onOpenChange,
  onSubmit,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [allowAnonymousQuestions, setAllowAnonymousQuestions] = useState(true);
  const [showLeaderboard, setShowLeaderboard] = useState(true);
  const [requirePreparation, setRequirePreparation] = useState(false);
  const [enableAIQuestions, setEnableAIQuestions] = useState(true);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title || !startTime || !endTime) {
      setError('Please fill in all required fields');
      return;
    }

    if (new Date(endTime) <= new Date(startTime)) {
      setError('End time must be after start time');
      return;
    }

    onSubmit({
      title,
      description,
      startTime: new Date(startTime).toISOString(),
      endTime: new Date(endTime).toISOString(),
      phase: 'pre' as EventPhase,
      allowAnonymousQuestions,
      showLeaderboard,
      requirePreparation,
      enableAIQuestions,
    });

    // Reset form
    setTitle('');
    setDescription('');
    setStartTime('');
    setEndTime('');
    setAllowAnonymousQuestions(true);
    setShowLeaderboard(true);
    setRequirePreparation(false);
    setEnableAIQuestions(true);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-card border-border">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Create New Event</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          {error && (
            <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
              {error}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Q4 Planning Meeting"
              className="bg-muted border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of the event..."
              className="bg-muted border-border resize-none"
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startTime">Start Time *</Label>
              <Input
                id="startTime"
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="bg-muted border-border"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endTime">End Time *</Label>
              <Input
                id="endTime"
                type="datetime-local"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="bg-muted border-border"
              />
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-border">
            <p className="text-sm font-medium text-foreground">Event Settings</p>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Anonymous Questions</p>
                <p className="text-xs text-muted-foreground">Allow participants to ask anonymously</p>
              </div>
              <Switch
                checked={allowAnonymousQuestions}
                onCheckedChange={setAllowAnonymousQuestions}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Show Leaderboard</p>
                <p className="text-xs text-muted-foreground">Display points ranking</p>
              </div>
              <Switch
                checked={showLeaderboard}
                onCheckedChange={setShowLeaderboard}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Require Preparation</p>
                <p className="text-xs text-muted-foreground">Prompt pre-meeting tasks</p>
              </div>
              <Switch
                checked={requirePreparation}
                onCheckedChange={setRequirePreparation}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Enable AI Q&A</p>
                <p className="text-xs text-muted-foreground">AI-powered post-meeting questions</p>
              </div>
              <Switch
                checked={enableAIQuestions}
                onCheckedChange={setEnableAIQuestions}
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              Create Event
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
