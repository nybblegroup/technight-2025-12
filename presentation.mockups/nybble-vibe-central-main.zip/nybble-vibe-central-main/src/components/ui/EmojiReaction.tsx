import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface FloatingEmoji {
  id: string;
  emoji: string;
  x: number;
}

interface EmojiReactionProps {
  emoji: string;
  onClick: () => void;
  disabled?: boolean;
  className?: string;
}

export const EmojiReaction: React.FC<EmojiReactionProps> = ({
  emoji,
  onClick,
  disabled = false,
  className,
}) => {
  const [floatingEmojis, setFloatingEmojis] = useState<FloatingEmoji[]>([]);

  const handleClick = () => {
    if (disabled) return;
    
    const id = Math.random().toString(36).substr(2, 9);
    const x = Math.random() * 20 - 10;
    
    setFloatingEmojis(prev => [...prev, { id, emoji, x }]);
    
    setTimeout(() => {
      setFloatingEmojis(prev => prev.filter(e => e.id !== id));
    }, 1500);
    
    onClick();
  };

  return (
    <div className="relative">
      <button
        onClick={handleClick}
        disabled={disabled}
        className={cn(
          'p-2 text-2xl rounded-lg transition-all duration-200',
          'hover:bg-muted hover:scale-110 active:scale-95',
          'disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100',
          className
        )}
      >
        {emoji}
      </button>
      
      <AnimatePresence>
        {floatingEmojis.map((item) => (
          <motion.span
            key={item.id}
            initial={{ opacity: 1, y: 0, x: 0, scale: 1 }}
            animate={{ 
              opacity: 0, 
              y: -80, 
              x: item.x,
              scale: 1.5,
              rotate: Math.random() * 30 - 15
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, ease: 'easeOut' }}
            className="absolute bottom-full left-1/2 -translate-x-1/2 text-2xl pointer-events-none"
          >
            {item.emoji}
          </motion.span>
        ))}
      </AnimatePresence>
    </div>
  );
};
