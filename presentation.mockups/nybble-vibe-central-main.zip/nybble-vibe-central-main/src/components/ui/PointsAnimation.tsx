import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PointsAnimationProps {
  points: number;
  show: boolean;
  onComplete?: () => void;
}

export const PointsAnimation: React.FC<PointsAnimationProps> = ({
  points,
  show,
  onComplete,
}) => {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onComplete?.();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [show, onComplete]);

  return (
    <AnimatePresence>
      {show && (
        <motion.span
          initial={{ opacity: 1, y: 0, scale: 1 }}
          animate={{ opacity: 0, y: -30, scale: 1.2 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className="absolute -top-2 left-full ml-2 text-success font-bold text-sm whitespace-nowrap pointer-events-none"
        >
          +{points} pts
        </motion.span>
      )}
    </AnimatePresence>
  );
};

// Hook for managing points animations
export const usePointsAnimation = () => {
  const [animations, setAnimations] = useState<{ id: string; points: number }[]>([]);

  const triggerAnimation = (points: number) => {
    const id = Math.random().toString(36).substr(2, 9);
    setAnimations(prev => [...prev, { id, points }]);
    
    setTimeout(() => {
      setAnimations(prev => prev.filter(a => a.id !== id));
    }, 1000);
  };

  return { animations, triggerAnimation };
};
