import { Event } from '@/data/mockData';
import { PhaseChip } from './PhaseChip';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { Calendar, Users } from 'lucide-react';
import { Link } from 'react-router-dom';

interface EventCardProps {
  event: Event;
  className?: string;
}

export const EventCard: React.FC<EventCardProps> = ({ event, className }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      <Link
        to={`/events/${event.id}`}
        className={cn(
          'block card-glow bg-card rounded-xl p-5 border border-border',
          'hover:border-primary/40 transition-all duration-300',
          event.phase === 'live' && 'border-live/30 glow-pulse',
          className
        )}
      >
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex-1 min-w-0">
            <h3 className="font-display font-semibold text-lg text-foreground truncate mb-1">
              {event.title}
            </h3>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {event.description}
            </p>
          </div>
          <PhaseChip phase={event.phase} size="sm" />
        </div>

        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4" />
            <span>{format(new Date(event.startTime), 'MMM d, h:mm a')}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Users className="w-4 h-4" />
            <span>{event.participantCount} participants</span>
          </div>
        </div>

        {event.phase === 'live' && (
          <div className="mt-4 pt-4 border-t border-border">
            <div className="flex items-center gap-2 text-live text-sm font-medium">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-live opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-live" />
              </span>
              Meeting in progress
            </div>
          </div>
        )}
      </Link>
    </motion.div>
  );
};
