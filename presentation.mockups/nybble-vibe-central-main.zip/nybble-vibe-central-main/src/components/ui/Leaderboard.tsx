import { Participant } from '@/data/mockData';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface LeaderboardProps {
  participants: Participant[];
  compact?: boolean;
  showBadges?: boolean;
  className?: string;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({
  participants,
  compact = false,
  showBadges = true,
  className,
}) => {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return '🥇';
      case 2:
        return '🥈';
      case 3:
        return '🥉';
      default:
        return null;
    }
  };

  return (
    <div className={cn('space-y-2', className)}>
      {participants.map((participant, index) => (
        <motion.div
          key={participant.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.05 }}
          className={cn(
            'flex items-center gap-3 p-3 rounded-lg bg-card/50 border border-border',
            'hover:border-primary/30 hover:bg-card transition-all duration-200',
            participant.rank <= 3 && 'border-primary/20'
          )}
        >
          <div className={cn(
            'flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm',
            participant.rank === 1 && 'bg-yellow-500/20 text-yellow-400',
            participant.rank === 2 && 'bg-gray-400/20 text-gray-300',
            participant.rank === 3 && 'bg-amber-600/20 text-amber-500',
            participant.rank > 3 && 'bg-muted text-muted-foreground'
          )}>
            {getRankIcon(participant.rank) || `#${participant.rank}`}
          </div>

          <div className={cn(
            'flex items-center justify-center w-10 h-10 rounded-full bg-primary/20 text-primary font-semibold',
            compact && 'w-8 h-8 text-sm'
          )}>
            {participant.avatar}
          </div>

          <div className="flex-1 min-w-0">
            <p className={cn(
              'font-medium text-foreground truncate',
              compact && 'text-sm'
            )}>
              {participant.name}
            </p>
            {!compact && (
              <p className="text-xs text-muted-foreground">
                {participant.eventsAttended} events • {participant.attendancePercent}% attendance
              </p>
            )}
          </div>

          {showBadges && participant.badges.length > 0 && !compact && (
            <div className="flex gap-1">
              {participant.badges.slice(0, 4).map((badge, i) => (
                <span key={i} className="text-lg">{badge}</span>
              ))}
            </div>
          )}

          <div className="text-right">
            <p className={cn(
              'font-bold text-primary font-display',
              compact ? 'text-sm' : 'text-lg'
            )}>
              {participant.points.toLocaleString()}
            </p>
            {!compact && (
              <p className="text-xs text-muted-foreground">points</p>
            )}
          </div>
        </motion.div>
      ))}
    </div>
  );
};
