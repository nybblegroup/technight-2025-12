import { cn } from '@/lib/utils';
import { EventPhase } from '@/data/mockData';

interface PhaseChipProps {
  phase: EventPhase;
  size?: 'sm' | 'md' | 'lg';
  showDot?: boolean;
}

const phaseConfig: Record<EventPhase, { label: string; className: string }> = {
  pre: {
    label: 'Pre-Meeting',
    className: 'bg-secondary/20 text-secondary border-secondary/30',
  },
  live: {
    label: 'LIVE',
    className: 'bg-live/20 text-live border-live/30',
  },
  post: {
    label: 'Post-Meeting',
    className: 'bg-success/20 text-success border-success/30',
  },
  closed: {
    label: 'Closed',
    className: 'bg-muted text-muted-foreground border-muted-foreground/30',
  },
};

const sizeClasses = {
  sm: 'text-xs px-2 py-0.5',
  md: 'text-sm px-3 py-1',
  lg: 'text-base px-4 py-1.5',
};

export const PhaseChip: React.FC<PhaseChipProps> = ({ phase, size = 'md', showDot = true }) => {
  const config = phaseConfig[phase];

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 font-medium rounded-full border',
        'transition-all duration-200',
        config.className,
        sizeClasses[size]
      )}
    >
      {showDot && phase === 'live' && (
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-live opacity-75" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-live" />
        </span>
      )}
      {config.label}
    </span>
  );
};
