import { Poll } from '@/data/mockData';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface PollResultsChartProps {
  poll: Poll;
  className?: string;
}

export const PollResultsChart: React.FC<PollResultsChartProps> = ({ poll, className }) => {
  const maxVotes = Math.max(...poll.options.map(o => o.votes), 1);

  return (
    <div className={cn('space-y-4', className)}>
      <div className="flex items-center justify-between">
        <h4 className="font-display font-semibold text-foreground">{poll.question}</h4>
        <span className="text-sm text-muted-foreground">{poll.totalVotes} votes</span>
      </div>

      <div className="space-y-3">
        {poll.options.map((option, index) => {
          const percentage = poll.totalVotes > 0 
            ? Math.round((option.votes / poll.totalVotes) * 100)
            : 0;
          const isWinning = option.votes === maxVotes && poll.totalVotes > 0;

          return (
            <div key={option.id} className="space-y-1.5">
              <div className="flex items-center justify-between text-sm">
                <span className={cn(
                  'text-foreground',
                  isWinning && 'font-medium'
                )}>
                  {option.text}
                </span>
                <span className={cn(
                  'text-muted-foreground',
                  isWinning && 'text-primary font-medium'
                )}>
                  {percentage}% ({option.votes})
                </span>
              </div>
              <div className="h-3 bg-muted rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${percentage}%` }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className={cn(
                    'h-full rounded-full',
                    isWinning 
                      ? 'bg-gradient-to-r from-primary to-secondary'
                      : 'bg-primary/60'
                  )}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
