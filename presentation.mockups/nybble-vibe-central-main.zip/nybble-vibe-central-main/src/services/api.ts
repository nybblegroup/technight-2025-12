import {
  mockEvents,
  mockParticipants,
  mockPolls,
  mockGlobalStats,
  mockEngagementTrends,
  mockAgendaItems,
  mockQuestions,
  mockCurrentUser,
  type Event,
  type Participant,
  type Poll,
  type GlobalStats,
  type EngagementTrend,
  type AgendaItem,
  type Question,
  type EventPhase,
} from '@/data/mockData';

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Random delay between 200-800ms
const randomDelay = () => delay(200 + Math.random() * 600);

// Events API
export const getEvents = async (): Promise<Event[]> => {
  await randomDelay();
  return [...mockEvents];
};

export const getEventById = async (id: string): Promise<Event | null> => {
  await randomDelay();
  return mockEvents.find(e => e.id === id) || null;
};

export const createEvent = async (event: Omit<Event, 'id' | 'participantCount' | 'hasTranscript'>): Promise<Event> => {
  await randomDelay();
  const newEvent: Event = {
    ...event,
    id: String(Date.now()),
    participantCount: 0,
    hasTranscript: false,
  };
  mockEvents.push(newEvent);
  return newEvent;
};

export const updateEventPhase = async (id: string, phase: EventPhase): Promise<Event | null> => {
  await randomDelay();
  const event = mockEvents.find(e => e.id === id);
  if (event) {
    event.phase = phase;
    return event;
  }
  return null;
};

// Participants API
export const getParticipants = async (): Promise<Participant[]> => {
  await randomDelay();
  return [...mockParticipants];
};

export const getParticipantsByEvent = async (eventId: string): Promise<Participant[]> => {
  await randomDelay();
  // In real app, filter by event
  return mockParticipants.slice(0, 8);
};

export const getTopParticipants = async (limit: number = 10): Promise<Participant[]> => {
  await randomDelay();
  return mockParticipants
    .sort((a, b) => b.points - a.points)
    .slice(0, limit);
};

// Polls API
export const getPolls = async (): Promise<Poll[]> => {
  await randomDelay();
  return [...mockPolls];
};

export const getPollsByEvent = async (eventId: string): Promise<Poll[]> => {
  await randomDelay();
  return mockPolls.filter(p => p.eventId === eventId);
};

export const getPollById = async (id: string): Promise<Poll | null> => {
  await randomDelay();
  return mockPolls.find(p => p.id === id) || null;
};

export const createPoll = async (poll: Omit<Poll, 'id' | 'totalVotes' | 'createdAt'>): Promise<Poll> => {
  await randomDelay();
  const newPoll: Poll = {
    ...poll,
    id: String(Date.now()),
    totalVotes: 0,
    createdAt: new Date().toISOString(),
  };
  mockPolls.push(newPoll);
  return newPoll;
};

export const updatePollStatus = async (id: string, status: Poll['status']): Promise<Poll | null> => {
  await randomDelay();
  const poll = mockPolls.find(p => p.id === id);
  if (poll) {
    poll.status = status;
    return poll;
  }
  return null;
};

export const votePoll = async (pollId: string, optionId: string): Promise<Poll | null> => {
  await randomDelay();
  const poll = mockPolls.find(p => p.id === pollId);
  if (poll) {
    const option = poll.options.find(o => o.id === optionId);
    if (option) {
      option.votes += 1;
      poll.totalVotes += 1;
    }
    return poll;
  }
  return null;
};

// Analytics API
export const getGlobalStats = async (): Promise<GlobalStats> => {
  await randomDelay();
  return { ...mockGlobalStats };
};

export const getEngagementTrends = async (): Promise<EngagementTrend[]> => {
  await randomDelay();
  return [...mockEngagementTrends];
};

// Extension-specific APIs
export const getAgendaItems = async (eventId: string): Promise<AgendaItem[]> => {
  await randomDelay();
  return [...mockAgendaItems];
};

export const getQuestions = async (eventId: string): Promise<Question[]> => {
  await randomDelay();
  return [...mockQuestions];
};

export const submitQuestion = async (eventId: string, text: string, isAnonymous: boolean): Promise<Question> => {
  await randomDelay();
  const newQuestion: Question = {
    id: String(Date.now()),
    text,
    isAnonymous,
    upvotes: 0,
    answered: false,
  };
  mockQuestions.push(newQuestion);
  return newQuestion;
};

export const getCurrentUser = async (): Promise<Participant> => {
  await randomDelay();
  return { ...mockCurrentUser };
};

export const submitFeedback = async (eventId: string, rating: number, goalAchieved: string, comments: string): Promise<void> => {
  await randomDelay();
  console.log('Feedback submitted:', { eventId, rating, goalAchieved, comments });
};

export const sendReaction = async (eventId: string, emoji: string): Promise<void> => {
  await delay(100);
  console.log('Reaction sent:', { eventId, emoji });
};

// AI Chat API (mock)
export const askAI = async (eventId: string, question: string): Promise<string> => {
  await delay(1500);
  const responses = [
    "Based on the meeting transcript, the main discussion points were around Q4 priorities and team alignment.",
    "The team agreed on focusing on customer feedback integration for the next sprint.",
    "Key action items include: updating the roadmap, scheduling follow-up meetings, and preparing demo materials.",
    "The consensus was to prioritize feature development while allocating 20% of capacity to technical debt.",
  ];
  return responses[Math.floor(Math.random() * responses.length)];
};
