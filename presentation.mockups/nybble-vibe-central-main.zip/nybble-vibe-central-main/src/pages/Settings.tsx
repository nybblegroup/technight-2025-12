import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useApp } from '@/contexts/AppContext';
import { defaultPointsConfig, PointsConfig } from '@/data/mockData';
import { Save, Eye, EyeOff, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

const Settings: React.FC = () => {
  const { pointsConfig, setPointsConfig, openAIKey, setOpenAIKey } = useApp();
  const [localConfig, setLocalConfig] = useState<PointsConfig>(pointsConfig);
  const [localApiKey, setLocalApiKey] = useState(openAIKey);
  const [showApiKey, setShowApiKey] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleConfigChange = (key: keyof PointsConfig, value: string) => {
    const numValue = parseInt(value) || 0;
    setLocalConfig({ ...localConfig, [key]: numValue });
  };

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    setPointsConfig(localConfig);
    setOpenAIKey(localApiKey);
    setIsSaving(false);
    toast.success('Settings saved successfully! ⚙️');
  };

  const handleReset = () => {
    setLocalConfig(defaultPointsConfig);
    toast.info('Points reset to defaults');
  };

  const pointsFields: { key: keyof PointsConfig; label: string; emoji: string }[] = [
    { key: 'attendance', label: 'Attendance Base', emoji: '✅' },
    { key: 'reaction', label: 'Reaction', emoji: '🔥' },
    { key: 'pollVote', label: 'Poll Vote', emoji: '📊' },
    { key: 'question', label: 'Ask Question', emoji: '❓' },
    { key: 'feedback', label: 'Submit Feedback', emoji: '💬' },
    { key: 'goalSet', label: 'Set Goal', emoji: '🎯' },
    { key: 'prepQuestion', label: 'Prep Question', emoji: '📝' },
  ];

  return (
    <DashboardLayout
      title="Settings"
      subtitle="Configure points and integrations"
      actions={
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? (
            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          Save Changes
        </Button>
      }
    >
      <div className="max-w-3xl space-y-8">
        {/* Points Configuration */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="card-glow bg-card rounded-xl p-6 border border-border">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-display font-semibold text-lg text-foreground">
                  🎮 Points Configuration
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Set how many points participants earn for each action
                </p>
              </div>
              <Button variant="outline" size="sm" onClick={handleReset}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Reset to Defaults
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {pointsFields.map((field) => (
                <div key={field.key} className="space-y-2">
                  <Label
                    htmlFor={field.key}
                    className="flex items-center gap-2"
                  >
                    <span>{field.emoji}</span>
                    {field.label}
                  </Label>
                  <div className="relative">
                    <Input
                      id={field.key}
                      type="number"
                      min={0}
                      max={1000}
                      value={localConfig[field.key]}
                      onChange={(e) =>
                        handleConfigChange(field.key, e.target.value)
                      }
                      className="bg-muted border-border pr-12"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                      pts
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Points Preview */}
            <div className="mt-6 pt-6 border-t border-border">
              <h4 className="font-medium text-foreground mb-4">Preview</h4>
              <div className="flex flex-wrap gap-3">
                {pointsFields.map((field) => (
                  <div
                    key={field.key}
                    className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-muted text-sm"
                  >
                    <span>{field.emoji}</span>
                    <span className="text-muted-foreground">{field.label}:</span>
                    <span className="font-bold text-success">
                      +{localConfig[field.key]} pts
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.section>

        {/* API Configuration */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="card-glow bg-card rounded-xl p-6 border border-border">
            <div className="mb-6">
              <h3 className="font-display font-semibold text-lg text-foreground">
                🤖 AI Configuration
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                Configure OpenAI integration for AI Q&A features
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="openai-key">OpenAI API Key</Label>
              <div className="relative">
                <Input
                  id="openai-key"
                  type={showApiKey ? 'text' : 'password'}
                  value={localApiKey}
                  onChange={(e) => setLocalApiKey(e.target.value)}
                  placeholder="sk-..."
                  className="bg-muted border-border pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showApiKey ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
              <p className="text-xs text-muted-foreground">
                Required for AI-powered post-meeting Q&A features
              </p>
            </div>

            {localApiKey && (
              <div className="mt-4 p-3 rounded-lg bg-success/10 border border-success/20">
                <div className="flex items-center gap-2 text-success text-sm">
                  <span>✓</span>
                  <span>API key configured</span>
                </div>
              </div>
            )}
          </div>
        </motion.section>

        {/* Info */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
            <p className="text-sm text-muted-foreground">
              <strong className="text-foreground">Note:</strong> Settings are
              stored locally for this demo. In production, these would be saved
              to your backend.
            </p>
          </div>
        </motion.section>
      </div>
    </DashboardLayout>
  );
};

export default Settings;
