import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { PollResultsChart } from '@/components/ui/PollResultsChart';
import { PollForm } from '@/components/forms/PollForm';
import { TableSkeleton } from '@/components/ui/SkeletonLoader';
import { Button } from '@/components/ui/button';
import { getPolls, updatePollStatus, getEvents } from '@/services/api';
import { Poll, Event } from '@/data/mockData';
import { Plus, Play, Square, Eye, EyeOff, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const Polls: React.FC = () => {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedPoll, setSelectedPoll] = useState<Poll | null>(null);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [pollsData, eventsData] = await Promise.all([
          getPolls(),
          getEvents(),
        ]);
        setPolls(pollsData);
        setEvents(eventsData);
        if (pollsData.length > 0) {
          setSelectedPoll(pollsData[0]);
        }
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const handleLaunchPoll = async (poll: Poll) => {
    const event = events.find(e => e.id === poll.eventId);
    if (event?.phase !== 'live') {
      toast.error('Can only launch polls during live events');
      return;
    }
    await updatePollStatus(poll.id, 'active');
    setPolls(polls.map(p => p.id === poll.id ? { ...p, status: 'active' } : p));
    toast.success('Poll launched! 🚀');
  };

  const handleClosePoll = async (poll: Poll) => {
    await updatePollStatus(poll.id, 'closed');
    setPolls(polls.map(p => p.id === poll.id ? { ...p, status: 'closed' } : p));
    toast.success('Poll closed');
  };

  const getStatusConfig = (status: Poll['status']) => {
    switch (status) {
      case 'active':
        return { label: 'Active', className: 'bg-success/20 text-success', icon: Play };
      case 'draft':
        return { label: 'Draft', className: 'bg-secondary/20 text-secondary', icon: Eye };
      case 'closed':
        return { label: 'Closed', className: 'bg-muted text-muted-foreground', icon: Square };
    }
  };

  const getVisibilityLabel = (visibility: Poll['showResultsTo']) => {
    switch (visibility) {
      case 'all':
        return 'All participants';
      case 'voted':
        return 'After voting';
      case 'admin':
        return 'Admin only';
    }
  };

  const getEventTitle = (eventId: string) => {
    return events.find(e => e.id === eventId)?.title || 'Unknown Event';
  };

  return (
    <DashboardLayout
      title="Polls"
      subtitle="Create and manage engagement polls"
      actions={
        <Button onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Create Poll
        </Button>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Polls List */}
        <div className="lg:col-span-2 space-y-4">
          {loading ? (
            <TableSkeleton rows={5} />
          ) : polls.length > 0 ? (
            polls.map((poll, index) => {
              const statusConfig = getStatusConfig(poll.status);
              const StatusIcon = statusConfig.icon;

              return (
                <motion.div
                  key={poll.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => setSelectedPoll(poll)}
                  className={cn(
                    'card-glow bg-card rounded-xl p-5 border cursor-pointer',
                    'transition-all duration-200',
                    selectedPoll?.id === poll.id
                      ? 'border-primary'
                      : 'border-border hover:border-primary/30'
                  )}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-foreground mb-1 truncate">
                        {poll.question}
                      </h3>
                      <p className="text-sm text-muted-foreground truncate">
                        📅 {getEventTitle(poll.eventId)}
                      </p>
                      <div className="flex items-center gap-4 mt-3">
                        <span
                          className={cn(
                            'inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium',
                            statusConfig.className
                          )}
                        >
                          <StatusIcon className="w-3 h-3" />
                          {statusConfig.label}
                        </span>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Users className="w-3 h-3" />
                          {poll.totalVotes} votes
                        </span>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          {poll.showResultsTo === 'admin' ? (
                            <EyeOff className="w-3 h-3" />
                          ) : (
                            <Eye className="w-3 h-3" />
                          )}
                          {getVisibilityLabel(poll.showResultsTo)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {poll.status === 'draft' && (
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleLaunchPoll(poll);
                          }}
                        >
                          <Play className="w-3 h-3 mr-1" />
                          Launch
                        </Button>
                      )}
                      {poll.status === 'active' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleClosePoll(poll);
                          }}
                        >
                          <Square className="w-3 h-3 mr-1" />
                          Close
                        </Button>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })
          ) : (
            <div className="text-center py-16 bg-card rounded-xl border border-border">
              <div className="text-4xl mb-4">📊</div>
              <p className="text-lg text-foreground font-medium mb-2">No polls yet</p>
              <p className="text-muted-foreground mb-6">
                Create your first poll to engage participants
              </p>
              <Button onClick={() => setShowForm(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Poll
              </Button>
            </div>
          )}
        </div>

        {/* Selected Poll Results */}
        <div>
          <div className="card-glow bg-card rounded-xl p-6 border border-border sticky top-24">
            <h3 className="font-display font-semibold text-lg text-foreground mb-4">
              📈 Poll Results
            </h3>
            {selectedPoll ? (
              <PollResultsChart poll={selectedPoll} />
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                Select a poll to view results
              </div>
            )}
          </div>
        </div>
      </div>

      <PollForm
        open={showForm}
        onOpenChange={setShowForm}
        onSubmit={(pollData) => {
          const newPoll: Poll = {
            ...pollData,
            id: String(Date.now()),
            totalVotes: 0,
            createdAt: new Date().toISOString(),
          };
          setPolls([newPoll, ...polls]);
          setSelectedPoll(newPoll);
          toast.success('Poll created! 📊');
        }}
        eventId={events[0]?.id || '1'}
      />
    </DashboardLayout>
  );
};

export default Polls;
