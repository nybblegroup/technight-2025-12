import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { ExtensionSidebar } from '@/components/extension/ExtensionSidebar';
import { motion } from 'framer-motion';

const ExtensionPreview: React.FC = () => {
  return (
    <DashboardLayout
      title="Extension Preview"
      subtitle="Preview the Chrome Extension sidebar UI"
    >
      <div className="flex items-start gap-8">
        {/* Description */}
        <div className="flex-1 max-w-xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="card-glow bg-card rounded-xl p-6 border border-border">
              <h3 className="font-display font-semibold text-lg text-foreground mb-4">
                🧩 Chrome Extension Sidebar
              </h3>
              <p className="text-muted-foreground mb-4">
                This is a preview of the Chrome Extension sidebar that appears alongside 
                Google Meet during events. It enables real-time gamification and engagement.
              </p>
              
              <div className="space-y-3">
                <h4 className="font-medium text-foreground text-sm">Features by Phase:</h4>
                
                <div className="grid gap-3">
                  <div className="p-3 rounded-lg bg-secondary/10 border border-secondary/20">
                    <p className="font-medium text-secondary text-sm">📋 Pre-Meeting</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Set goals, prepare questions, view agenda
                    </p>
                  </div>
                  
                  <div className="p-3 rounded-lg bg-live/10 border border-live/20">
                    <p className="font-medium text-live text-sm">🔴 Live Meeting</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Vote in polls, send reactions, ask questions
                    </p>
                  </div>
                  
                  <div className="p-3 rounded-lg bg-success/10 border border-success/20">
                    <p className="font-medium text-success text-sm">✅ Post-Meeting</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      View stats, rate meeting, AI Q&A
                    </p>
                  </div>
                  
                  <div className="p-3 rounded-lg bg-muted border border-border">
                    <p className="font-medium text-muted-foreground text-sm">🔒 Closed</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Final results, leaderboard, event summary
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="card-glow bg-card rounded-xl p-6 border border-border">
              <h3 className="font-display font-semibold text-lg text-foreground mb-4">
                🎮 Gamification Points
              </h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {[
                  { action: 'Attendance', points: 50, emoji: '✅' },
                  { action: 'Set Goal', points: 20, emoji: '🎯' },
                  { action: 'Prep Question', points: 15, emoji: '📝' },
                  { action: 'Poll Vote', points: 15, emoji: '📊' },
                  { action: 'Ask Question', points: 25, emoji: '❓' },
                  { action: 'Reaction', points: 5, emoji: '🔥' },
                  { action: 'Submit Feedback', points: 40, emoji: '💬' },
                ].map((item) => (
                  <div
                    key={item.action}
                    className="flex items-center justify-between p-2 rounded-lg bg-muted"
                  >
                    <span className="flex items-center gap-2">
                      <span>{item.emoji}</span>
                      <span className="text-foreground">{item.action}</span>
                    </span>
                    <span className="text-success font-bold">+{item.points}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Extension Preview */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="sticky top-24"
        >
          <div className="rounded-xl overflow-hidden shadow-2xl border border-border">
            <div className="bg-muted px-4 py-2 flex items-center gap-2 border-b border-border">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-destructive/60" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                <div className="w-3 h-3 rounded-full bg-success/60" />
              </div>
              <span className="text-xs text-muted-foreground ml-2">
                Nybble Vibe Extension
              </span>
            </div>
            <div className="h-[600px]">
              <ExtensionSidebar />
            </div>
          </div>
        </motion.div>
      </div>
    </DashboardLayout>
  );
};

export default ExtensionPreview;
