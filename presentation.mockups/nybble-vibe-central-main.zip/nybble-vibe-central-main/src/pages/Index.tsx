import Dashboard from './Dashboard';

// Redirect to Dashboard
const Index = () => <Dashboard />;

export default Index;
