import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { PhaseChip } from '@/components/ui/PhaseChip';
import { Leaderboard } from '@/components/ui/Leaderboard';
import { PollResultsChart } from '@/components/ui/PollResultsChart';
import { PollForm } from '@/components/forms/PollForm';
import { KPICard } from '@/components/ui/KPICard';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  getEventById,
  getParticipantsByEvent,
  getPollsByEvent,
  updateEventPhase,
} from '@/services/api';
import { Event, Participant, Poll, EventPhase } from '@/data/mockData';
import { format } from 'date-fns';
import {
  ArrowLeft,
  Users,
  Vote,
  FileText,
  Calendar,
  Clock,
  ChevronRight,
  Upload,
  CheckCircle2,
  Plus,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

const phaseOrder: EventPhase[] = ['pre', 'live', 'post', 'closed'];

const EventDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [event, setEvent] = useState<Event | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [polls, setPolls] = useState<Poll[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPollForm, setShowPollForm] = useState(false);
  const [transcriptUploaded, setTranscriptUploaded] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const [eventData, participantsData, pollsData] = await Promise.all([
          getEventById(id),
          getParticipantsByEvent(id),
          getPollsByEvent(id),
        ]);
        setEvent(eventData);
        setParticipants(participantsData);
        setPolls(pollsData);
        setTranscriptUploaded(eventData?.hasTranscript || false);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [id]);

  const handlePhaseChange = async () => {
    if (!event) return;
    const currentIndex = phaseOrder.indexOf(event.phase);
    if (currentIndex < phaseOrder.length - 1) {
      const nextPhase = phaseOrder[currentIndex + 1];
      await updateEventPhase(event.id, nextPhase);
      setEvent({ ...event, phase: nextPhase });
      toast.success(`Event moved to ${nextPhase} phase`);
    }
  };

  const handleTranscriptUpload = () => {
    setTranscriptUploaded(true);
    toast.success('Transcript uploaded! AI Q&A is now enabled 🤖');
  };

  const getNextPhaseLabel = () => {
    if (!event) return '';
    const currentIndex = phaseOrder.indexOf(event.phase);
    if (currentIndex < phaseOrder.length - 1) {
      const nextPhase = phaseOrder[currentIndex + 1];
      return nextPhase === 'live' ? 'Go Live' : `Move to ${nextPhase}`;
    }
    return 'Closed';
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading event...</div>
        </div>
      </DashboardLayout>
    );
  }

  if (!event) {
    return (
      <DashboardLayout>
        <div className="text-center py-16">
          <p className="text-lg text-foreground mb-4">Event not found</p>
          <Link to="/events">
            <Button variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Events
            </Button>
          </Link>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-8">
        <Link
          to="/events"
          className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back to Events
        </Link>

        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="font-display font-bold text-2xl text-foreground">
                {event.title}
              </h1>
              <PhaseChip phase={event.phase} />
            </div>
            <p className="text-muted-foreground max-w-2xl">{event.description}</p>
            <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {format(new Date(event.startTime), 'MMM d, yyyy')}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {format(new Date(event.startTime), 'h:mm a')} -{' '}
                {format(new Date(event.endTime), 'h:mm a')}
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                {event.participantCount} participants
              </span>
            </div>
          </div>

          {event.phase !== 'closed' && (
            <Button onClick={handlePhaseChange} className="shrink-0">
              {getNextPhaseLabel()}
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="bg-card border border-border">
          <TabsTrigger value="overview">📊 Overview</TabsTrigger>
          <TabsTrigger value="participants">👥 Participants</TabsTrigger>
          <TabsTrigger value="polls">📋 Polls</TabsTrigger>
          <TabsTrigger value="transcript">📝 Transcript</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <KPICard
              title="Participants"
              value={event.participantCount}
              icon={<Users className="w-6 h-6" />}
            />
            <KPICard
              title="Active Polls"
              value={polls.filter(p => p.status === 'active').length}
              icon={<Vote className="w-6 h-6" />}
            />
            <KPICard
              title="Total Votes"
              value={polls.reduce((acc, p) => acc + p.totalVotes, 0)}
              icon={<CheckCircle2 className="w-6 h-6" />}
            />
            <KPICard
              title="AI Q&A"
              value={transcriptUploaded ? 'Enabled' : 'Disabled'}
              icon={<FileText className="w-6 h-6" />}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card-glow bg-card rounded-xl p-6 border border-border">
              <h3 className="font-display font-semibold text-lg text-foreground mb-4">
                Event Settings
              </h3>
              <div className="space-y-3">
                {[
                  { label: 'Anonymous Questions', enabled: event.allowAnonymousQuestions },
                  { label: 'Leaderboard', enabled: event.showLeaderboard },
                  { label: 'Require Preparation', enabled: event.requirePreparation },
                  { label: 'AI Questions', enabled: event.enableAIQuestions },
                ].map((setting) => (
                  <div
                    key={setting.label}
                    className="flex items-center justify-between py-2 border-b border-border last:border-0"
                  >
                    <span className="text-foreground">{setting.label}</span>
                    <span
                      className={
                        setting.enabled ? 'text-success' : 'text-muted-foreground'
                      }
                    >
                      {setting.enabled ? '✓ Enabled' : '✗ Disabled'}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {polls.length > 0 && (
              <div className="card-glow bg-card rounded-xl p-6 border border-border">
                <h3 className="font-display font-semibold text-lg text-foreground mb-4">
                  Latest Poll Results
                </h3>
                <PollResultsChart poll={polls[0]} />
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="participants">
          <div className="card-glow bg-card rounded-xl p-6 border border-border">
            <h3 className="font-display font-semibold text-lg text-foreground mb-4">
              🏆 Event Leaderboard
            </h3>
            <Leaderboard participants={participants} />
          </div>
        </TabsContent>

        <TabsContent value="polls">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-display font-semibold text-lg text-foreground">
              Event Polls
            </h3>
            <Button onClick={() => setShowPollForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Poll
            </Button>
          </div>

          {polls.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {polls.map((poll) => (
                <motion.div
                  key={poll.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="card-glow bg-card rounded-xl p-6 border border-border"
                >
                  <div className="flex items-center justify-between mb-4">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        poll.status === 'active'
                          ? 'bg-success/20 text-success'
                          : poll.status === 'draft'
                          ? 'bg-secondary/20 text-secondary'
                          : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      {poll.status}
                    </span>
                  </div>
                  <PollResultsChart poll={poll} />
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-card rounded-xl border border-border">
              <div className="text-4xl mb-4">📊</div>
              <p className="text-lg text-foreground font-medium mb-2">No polls yet</p>
              <p className="text-muted-foreground mb-6">
                Create a poll to engage your participants
              </p>
              <Button onClick={() => setShowPollForm(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create First Poll
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="transcript">
          <div className="card-glow bg-card rounded-xl p-8 border border-border">
            {transcriptUploaded ? (
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-success/20 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8 text-success" />
                </div>
                <h3 className="font-display font-semibold text-xl text-foreground mb-2">
                  Transcript Uploaded
                </h3>
                <p className="text-muted-foreground mb-4">
                  AI Q&A is now enabled for this event. Participants can ask questions
                  about the meeting content.
                </p>
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/10 text-primary">
                  🤖 AI Q&A Ready
                </div>
              </div>
            ) : (
              <div className="text-center">
                <div
                  className="border-2 border-dashed border-border rounded-xl p-12 hover:border-primary/50 transition-colors cursor-pointer"
                  onClick={handleTranscriptUpload}
                >
                  <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-display font-semibold text-xl text-foreground mb-2">
                    Upload Transcript
                  </h3>
                  <p className="text-muted-foreground mb-4 max-w-md mx-auto">
                    Upload the meeting transcript to enable AI-powered Q&A for
                    participants
                  </p>
                  <Button>
                    <Upload className="w-4 h-4 mr-2" />
                    Choose File
                  </Button>
                </div>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      <PollForm
        open={showPollForm}
        onOpenChange={setShowPollForm}
        onSubmit={(pollData) => {
          const newPoll: Poll = {
            ...pollData,
            id: String(Date.now()),
            totalVotes: 0,
            createdAt: new Date().toISOString(),
          };
          setPolls([...polls, newPoll]);
          toast.success('Poll created! 📊');
        }}
        eventId={id || ''}
      />
    </DashboardLayout>
  );
};

export default EventDetail;
