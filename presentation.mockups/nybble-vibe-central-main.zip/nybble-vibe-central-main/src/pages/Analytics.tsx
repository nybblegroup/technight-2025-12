import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { KPICard } from '@/components/ui/KPICard';
import { Leaderboard } from '@/components/ui/Leaderboard';
import { KPICardSkeleton, LeaderboardSkeleton } from '@/components/ui/SkeletonLoader';
import { getGlobalStats, getTopParticipants, getEngagementTrends } from '@/services/api';
import { GlobalStats, Participant, EngagementTrend } from '@/data/mockData';
import {
  Star,
  Users,
  Vote,
  MessageSquare,
  Calendar,
  Target,
  TrendingUp,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
} from 'recharts';
import { motion } from 'framer-motion';

const Analytics: React.FC = () => {
  const [stats, setStats] = useState<GlobalStats | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [trends, setTrends] = useState<EngagementTrend[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [statsData, participantsData, trendsData] = await Promise.all([
          getGlobalStats(),
          getTopParticipants(10),
          getEngagementTrends(),
        ]);
        setStats(statsData);
        setParticipants(participantsData);
        setTrends(trendsData);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  return (
    <DashboardLayout
      title="Analytics"
      subtitle="Track engagement metrics and performance"
    >
      <div className="space-y-8">
        {/* KPI Cards */}
        <section>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {loading ? (
              <>
                <KPICardSkeleton />
                <KPICardSkeleton />
                <KPICardSkeleton />
                <KPICardSkeleton />
              </>
            ) : (
              <>
                <KPICard
                  title="Average Rating"
                  value={stats?.averageRating || 0}
                  suffix="/5"
                  icon={<Star className="w-6 h-6" />}
                  trend={{ value: 8, isPositive: true }}
                />
                <KPICard
                  title="Attendance Rate"
                  value={stats?.attendanceRate || 0}
                  suffix="%"
                  icon={<Users className="w-6 h-6" />}
                  trend={{ value: 3, isPositive: true }}
                />
                <KPICard
                  title="Poll Participation"
                  value={stats?.pollParticipation || 0}
                  suffix="%"
                  icon={<Vote className="w-6 h-6" />}
                  trend={{ value: 12, isPositive: true }}
                />
                <KPICard
                  title="Feedback Completion"
                  value={stats?.feedbackCompletion || 0}
                  suffix="%"
                  icon={<MessageSquare className="w-6 h-6" />}
                  trend={{ value: 5, isPositive: false }}
                />
              </>
            )}
          </div>
        </section>

        {/* Secondary Stats */}
        <section>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {loading ? (
              <>
                <KPICardSkeleton />
                <KPICardSkeleton />
                <KPICardSkeleton />
              </>
            ) : (
              <>
                <KPICard
                  title="Total Events"
                  value={stats?.totalEvents || 0}
                  icon={<Calendar className="w-6 h-6" />}
                />
                <KPICard
                  title="Total Participants"
                  value={stats?.totalParticipants || 0}
                  icon={<Users className="w-6 h-6" />}
                />
                <KPICard
                  title="Total Points Earned"
                  value={(stats?.totalPoints || 0).toLocaleString()}
                  icon={<Target className="w-6 h-6" />}
                />
              </>
            )}
          </div>
        </section>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Engagement Trend */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="card-glow bg-card rounded-xl p-6 border border-border h-full">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-display font-semibold text-lg text-foreground flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  Engagement Trend
                </h3>
              </div>
              {loading ? (
                <div className="h-64 skeleton-shimmer rounded-lg" />
              ) : (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trends}>
                      <defs>
                        <linearGradient id="colorEngagement2" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(239, 84%, 67%)" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(239, 84%, 67%)" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <XAxis
                        dataKey="month"
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: 'hsl(240, 5%, 65%)' }}
                      />
                      <YAxis
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: 'hsl(240, 5%, 65%)' }}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(240, 6%, 10%)',
                          border: '1px solid hsl(240, 5%, 18%)',
                          borderRadius: '8px',
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="engagement"
                        stroke="hsl(239, 84%, 67%)"
                        strokeWidth={2}
                        fillOpacity={1}
                        fill="url(#colorEngagement2)"
                        name="Engagement %"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </motion.section>

          {/* Participation Comparison */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="card-glow bg-card rounded-xl p-6 border border-border h-full">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-display font-semibold text-lg text-foreground">
                  📊 Monthly Comparison
                </h3>
              </div>
              {loading ? (
                <div className="h-64 skeleton-shimmer rounded-lg" />
              ) : (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={trends}>
                      <XAxis
                        dataKey="month"
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: 'hsl(240, 5%, 65%)' }}
                      />
                      <YAxis
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: 'hsl(240, 5%, 65%)' }}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(240, 6%, 10%)',
                          border: '1px solid hsl(240, 5%, 18%)',
                          borderRadius: '8px',
                        }}
                      />
                      <Bar
                        dataKey="attendance"
                        fill="hsl(239, 84%, 67%)"
                        radius={[4, 4, 0, 0]}
                        name="Attendance %"
                      />
                      <Bar
                        dataKey="participation"
                        fill="hsl(187, 94%, 47%)"
                        radius={[4, 4, 0, 0]}
                        name="Participation %"
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </motion.section>
        </div>

        {/* Global Leaderboard */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <div className="card-glow bg-card rounded-xl p-6 border border-border">
            <h3 className="font-display font-semibold text-xl text-foreground mb-6">
              🏆 Global Leaderboard - Top 10
            </h3>
            {loading ? (
              <LeaderboardSkeleton />
            ) : (
              <Leaderboard participants={participants} />
            )}
          </div>
        </motion.section>
      </div>
    </DashboardLayout>
  );
};

export default Analytics;
