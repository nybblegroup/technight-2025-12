import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { KPICard } from '@/components/ui/KPICard';
import { EventCard } from '@/components/ui/EventCard';
import { Leaderboard } from '@/components/ui/Leaderboard';
import { KPICardSkeleton, EventCardSkeleton, LeaderboardSkeleton } from '@/components/ui/SkeletonLoader';
import { useApp } from '@/contexts/AppContext';
import { getEvents, getGlobalStats, getTopParticipants, getEngagementTrends } from '@/services/api';
import { Star, Users, Vote, MessageSquare, TrendingUp } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const Dashboard: React.FC = () => {
  const { events, setEvents, participants, setParticipants, globalStats, setGlobalStats } = useApp();
  const [trends, setTrends] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [eventsData, statsData, participantsData, trendsData] = await Promise.all([
          getEvents(),
          getGlobalStats(),
          getTopParticipants(5),
          getEngagementTrends(),
        ]);
        setEvents(eventsData);
        setGlobalStats(statsData);
        setParticipants(participantsData);
        setTrends(trendsData);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const liveEvents = events.filter(e => e.phase === 'live');
  const upcomingEvents = events.filter(e => e.phase === 'pre').slice(0, 3);

  return (
    <DashboardLayout
      title="Dashboard"
      subtitle="Welcome back! Here's what's happening."
      actions={
        <Link to="/events">
          <Button>View All Events</Button>
        </Link>
      }
    >
      <div className="space-y-8">
        {/* KPI Cards */}
        <section>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {loading ? (
              <>
                <KPICardSkeleton />
                <KPICardSkeleton />
                <KPICardSkeleton />
                <KPICardSkeleton />
              </>
            ) : (
              <>
                <KPICard
                  title="Average Rating"
                  value={globalStats?.averageRating || 0}
                  suffix="/5"
                  icon={<Star className="w-6 h-6" />}
                  trend={{ value: 8, isPositive: true }}
                />
                <KPICard
                  title="Attendance Rate"
                  value={globalStats?.attendanceRate || 0}
                  suffix="%"
                  icon={<Users className="w-6 h-6" />}
                  trend={{ value: 3, isPositive: true }}
                />
                <KPICard
                  title="Poll Participation"
                  value={globalStats?.pollParticipation || 0}
                  suffix="%"
                  icon={<Vote className="w-6 h-6" />}
                  trend={{ value: 12, isPositive: true }}
                />
                <KPICard
                  title="Feedback Completion"
                  value={globalStats?.feedbackCompletion || 0}
                  suffix="%"
                  icon={<MessageSquare className="w-6 h-6" />}
                  trend={{ value: 5, isPositive: false }}
                />
              </>
            )}
          </div>
        </section>

        {/* Live Events */}
        {liveEvents.length > 0 && (
          <section>
            <h2 className="font-display font-semibold text-lg text-foreground mb-4 flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-live opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-live" />
              </span>
              Live Now
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {liveEvents.map(event => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
          </section>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Engagement Trends */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <div className="card-glow bg-card rounded-xl p-6 border border-border">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-display font-semibold text-lg text-foreground flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  Engagement Trends
                </h3>
                <span className="text-sm text-muted-foreground">Last 4 months</span>
              </div>
              {loading ? (
                <div className="h-64 skeleton-shimmer rounded-lg" />
              ) : (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trends}>
                      <defs>
                        <linearGradient id="colorEngagement" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(239, 84%, 67%)" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(239, 84%, 67%)" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="colorAttendance" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(187, 94%, 47%)" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(187, 94%, 47%)" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <XAxis
                        dataKey="month"
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: 'hsl(240, 5%, 65%)' }}
                      />
                      <YAxis
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: 'hsl(240, 5%, 65%)' }}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(240, 6%, 10%)',
                          border: '1px solid hsl(240, 5%, 18%)',
                          borderRadius: '8px',
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="engagement"
                        stroke="hsl(239, 84%, 67%)"
                        strokeWidth={2}
                        fillOpacity={1}
                        fill="url(#colorEngagement)"
                      />
                      <Area
                        type="monotone"
                        dataKey="attendance"
                        stroke="hsl(187, 94%, 47%)"
                        strokeWidth={2}
                        fillOpacity={1}
                        fill="url(#colorAttendance)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </motion.section>

          {/* Top Performers */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="card-glow bg-card rounded-xl p-6 border border-border h-full">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display font-semibold text-lg text-foreground">
                  🏆 Top Performers
                </h3>
                <Link to="/analytics" className="text-sm text-primary hover:underline">
                  View all
                </Link>
              </div>
              {loading ? (
                <LeaderboardSkeleton />
              ) : (
                <Leaderboard participants={participants} compact />
              )}
            </div>
          </motion.section>
        </div>

        {/* Upcoming Events */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-lg text-foreground">
              📅 Upcoming Events
            </h2>
            <Link to="/events" className="text-sm text-primary hover:underline">
              View all
            </Link>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <EventCardSkeleton />
              <EventCardSkeleton />
              <EventCardSkeleton />
            </div>
          ) : upcomingEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {upcomingEvents.map(event => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-card rounded-xl border border-border">
              <p className="text-muted-foreground">No upcoming events</p>
            </div>
          )}
        </section>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;
