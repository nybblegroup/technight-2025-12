import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { EventCard } from '@/components/ui/EventCard';
import { EventCardSkeleton } from '@/components/ui/SkeletonLoader';
import { EventForm } from '@/components/forms/EventForm';
import { useApp } from '@/contexts/AppContext';
import { getEvents, createEvent } from '@/services/api';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Filter } from 'lucide-react';
import { Event, EventPhase } from '@/data/mockData';
import { toast } from 'sonner';

const Events: React.FC = () => {
  const { events, setEvents, addEvent } = useApp();
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [phaseFilter, setPhaseFilter] = useState<EventPhase | 'all'>('all');

  useEffect(() => {
    const loadEvents = async () => {
      setLoading(true);
      try {
        const data = await getEvents();
        setEvents(data);
      } finally {
        setLoading(false);
      }
    };
    loadEvents();
  }, []);

  const handleCreateEvent = async (eventData: Omit<Event, 'id' | 'participantCount' | 'hasTranscript'>) => {
    const newEvent = await createEvent(eventData);
    addEvent(newEvent);
    toast.success('Event created successfully! 🎉');
  };

  const filteredEvents = events.filter(
    e => phaseFilter === 'all' || e.phase === phaseFilter
  );

  const getPhaseEmoji = (phase: EventPhase | 'all') => {
    switch (phase) {
      case 'pre': return '📋';
      case 'live': return '🔴';
      case 'post': return '✅';
      case 'closed': return '🔒';
      default: return '📅';
    }
  };

  return (
    <DashboardLayout
      title="Events"
      subtitle="Manage your event engagement sessions"
      actions={
        <Button onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Create Event
        </Button>
      }
    >
      {/* Filters */}
      <div className="flex items-center gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Filter by:</span>
        </div>
        <Select value={phaseFilter} onValueChange={(v) => setPhaseFilter(v as any)}>
          <SelectTrigger className="w-[180px] bg-card border-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">📅 All Events</SelectItem>
            <SelectItem value="pre">📋 Pre-Meeting</SelectItem>
            <SelectItem value="live">🔴 Live</SelectItem>
            <SelectItem value="post">✅ Post-Meeting</SelectItem>
            <SelectItem value="closed">🔒 Closed</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-sm text-muted-foreground">
          {filteredEvents.length} event{filteredEvents.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Events Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <EventCardSkeleton key={i} />
          ))}
        </div>
      ) : filteredEvents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredEvents.map(event => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-card rounded-xl border border-border">
          <div className="text-4xl mb-4">{getPhaseEmoji(phaseFilter)}</div>
          <p className="text-lg text-foreground font-medium mb-2">No events found</p>
          <p className="text-muted-foreground mb-6">
            {phaseFilter === 'all' 
              ? "You haven't created any events yet." 
              : `No ${phaseFilter} events at the moment.`}
          </p>
          <Button onClick={() => setShowForm(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Your First Event
          </Button>
        </div>
      )}

      <EventForm
        open={showForm}
        onOpenChange={setShowForm}
        onSubmit={handleCreateEvent}
      />
    </DashboardLayout>
  );
};

export default Events;
